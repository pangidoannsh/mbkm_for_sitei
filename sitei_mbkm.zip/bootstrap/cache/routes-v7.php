<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tPafewG95jjT8IvF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JHPyS0XcFJgapc6s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'doc.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/arsip' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'doc.arsip',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pengumuman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pengumuman/arsip' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.arsip',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pengumuman/pengelola' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.pengelola',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pengumuman/pengelola/arsip' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.pengelola.arsip',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pengumuman/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/dokumen/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dokumen.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/dokumen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dokumen.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/suratcuti/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/suratcuti' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/surat/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/surat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/sertifikat/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/sertifikat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/pengelola' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengelola',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/pengelola/pengumuman' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengelola.pengumuman',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/distribusi-dokumen/pengelola/arsip' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengelola.arsip',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/semester' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'semester.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/semester/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'logo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/mahasiswa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/mahasiswa/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/mahasiswa/riwayat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.riwayat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/usulan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/sertifikat/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.sertif.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/sertifikat/create/konversi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.sertif.storekonversi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/prodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.prodi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/berjalan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.prodi.berjalan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/riwayat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.prodi.riwayat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/staff' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.staff',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/staff/riwayat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.staff.riwayat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mbkm/staff-print' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'staff.print',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/program-mbkm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program-mbkm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program-mbkm.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/matkul' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'matkul',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'matkul.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/matkul/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'matkul.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/developer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BbOoiDA660dDdGom',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/developer/fahril-hadi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9NdjlTPxv8q8N2UP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/developer/m-seprinaldi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VJMTRTFsgyfNMyxx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/developer/rahul-ilsa-tajri-mukhti' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r03cNvB9CM7Ocz1l',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/developer/ahmad-fajri' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RBsto8yoZCTaNZ18',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/developer/yabes-maychel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JpvX1Ka6Ay4916Jm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/developer/yasmine' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YtdcRmHPFYHBxzSE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FarFvfZ1FpS8aTFv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dm0Qlw8otHZLSZOQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/usulankp/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::47OFaiFqp3Stn35v',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/usulankp/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JAJsHRiWAsNdMiCU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fg8Z4mZl5HR3OFaB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/usulankp-ulang/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8Oe72jsTXQmHcnZp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xy2TWC441nImZmuA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/usuljudul/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MV8btF9W1mHwh2g0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/usuljudul/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qia2ZvjbC81hwwGv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lWApoGqr9UE4WVTA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/usuljudul-ulang/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JWWO5WR148R3QQuF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rN7FYbt5Bct5keyh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/permohonankp/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zipificsTxnf6jkC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/balasankp/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K9sJcekwshTn4Ugp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/seminarkp/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e9IO4cQlsJG28JhK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kpti10-kp/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jelP9Pif8ngpJDIw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/daftar-sempro/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wPdbuPLYCsamKNZq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/daftar-sidang/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::31XGAqYw7yE6hVMQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profil-mhs/editpasswordmhs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GrXptYTIwfBbq4xf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uuqXBuo60MSTcoRr',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/jadwal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SXsGtNssj6Pettow',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/jadwal/mahasiswa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1c3p4CHuT4RelgPm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/seminar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gj5xE4BIzG017CNz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/daftar-kp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HxrcyZSsqYv8XPu5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/daftar-kp/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DpSPdIXMwFfrSP4X',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YAcqF3BwcW8LUQgV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/status-kp/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p4EdSPngRcuguvkW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WffPEr0AscPZBHdO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/peminjamanmhs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'peminjaman',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/riwayatmhs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'riwayatmhs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/formpinjam' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'formusulan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/usulan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iF8mxU4CfpdU913w',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kerja-praktek/admin/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gkcky5CCtbEOms7x',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sempro/admin/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zI9Kc2lKaVKwQgbe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sidang/admin/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rW6yD5SCS0wRPC0O',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/persetujuan/admin/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4PjcE5RvZLCWFKIw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profil-staff/editpasswordstaff' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5p5aAAyhJGmXfBkG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SsHYMHRafHWlCvrC',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dosen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HjMCC8GEjTq83O0L',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dosen/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uOhEU9DAK5ZgWOA9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kdZ9AWAIGBEgOqh3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mahasiswa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dxmdkDJEF7Ivvv5y',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mahasiswa/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ibPCEacXWPEF37iD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cah0iuar4VLTXaLO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/role' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IgbBjJsb8XOQvPc8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/role/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T9nqH1bIQb71LCFv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CxWKitsBxItZyhq9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/prodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DTAdgMUAZi1jNG5G',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/prodi/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xSdnAhQNUAZ7Sn4D',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5K3gS1fEpIPVwZZ8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konsentrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a9rJSf21II8B8NIn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/konsentrasi/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K1xCbWyaY8tLXaAc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yX7YbgDdHMd4DDAj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EykWiB056HHs7jqC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pkVOopk5xJi47hAE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V7RtLyIgWdBRj7N0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/plp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ap2pbkH4DXZWoUmR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/plp/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BOjr3P7M72LK6y2E',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m6rAFAFR0xcN6OZQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pendaftaran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vv58rxtwWhUO7Q3o',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kerja-praktek' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ewF8toVVUskGnmyp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kp-skripsi/pembimbing-penguji/riwayat-seminar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rzkAaPsqDp2qgTip',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pembimbing-penguji/riwayat-bimbingan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z3VaWI11Dzf8c6Sq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xVQ5GvoYNgT4Pi5Y',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/persetujuan-kp-skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7TqUOqAZiIoKTr7Z',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kp-skripsi/persetujuan-skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NXNzj80PBq5ktsqH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pembimbing/kerja-praktek' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LH4i8xTJi6flFDLi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pembimbing/skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vn9fULNUyvGAK1A8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pendaftaran/kp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PdHOOGXf67RlBgO5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayatkp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BhoASjP66tRQ8MpI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profil-dosen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ivsfgn62fstZmS72',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profil-dosen/editpassworddsn' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fMyjavhDfr7YSkFH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HdjgfO6rclprnnVe',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/prodi/kp-skripsi/seminar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9vanXxjzJscyPjZ3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kp-skripsi/seminar-pembimbing-penguji' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DMu1lRqOTQch67wc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kp-skripsi/riwayat-penilaian-seminar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EPkgteyjUYlDE5hI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kp-skripsi/riwayat-penilaian-skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3IzWP3FqvoR6eexw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/penilaian-kp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J3XlRKp335xqFf6z',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayat-penilaian-kp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Wm9WnsiSdVn2oTyV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/penilaian-sempro' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rKDdfhDW5vNxYvaZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayat-penilaian-sempro' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BV7zBz8Wr99e9uxJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/penilaian-skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mLZKOxVRYo3gCIOi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayat-penilaian-skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AwsSojlfOFGPNFew',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/peminjaman-dosen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'peminjamandsn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/riwayat-dosen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'riwayatdsn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/formpinjam-dosen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'formusulandosen',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/usulan-dosen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4IUhEN5WjgKwFXbm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayat-penjadwalan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RaOnob9BOQZQRlGP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/clear' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9B3tvwccSACkrPPP',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/form-kp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vpTwPD4qj5rnt8XQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/form-kp/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gq5a0KEs9moiqRl0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cgnOS6olb6QfxyhH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayat-penjadwalan-kp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3dNTTmJQsW3I08Ta',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/form-sempro' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f5Pearnv5CeBPI4i',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/form-sempro/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jud65JdTvavwL3X7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rUboLUO1ZSXwcgSB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayat-penjadwalan-sempro' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aNl4mHdAv0KOPZFh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/form-skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HX0HwEGh0Bpu0Z5f',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/form-skripsi/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6dHllkwf5B6EeXRU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B5ZO77tx0Soo4j9R',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayat-penjadwalan-skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tTq7E4HSBfNES031',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/peminjamanadm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'peminjamanadm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/riwayatadm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'riwayatadm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/stok' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'stok',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/stokbaru' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'stokbaru',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/tambahbarang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tambahbarang',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kapasitas-bimbingan/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pupl5F3XfP8UH09V',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statistik' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KAkUwHck3UQ1aWWb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statistik/bimbingan-kp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TTzSDS6ihVjmzEDI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statistik/bimbingan-skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zhYPS0SYXzweR8tI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statistik/judul-skripsi-terdaftar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a4Z9aESJMcdxDP2s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statistik/riwayat-kp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NTlny6MDIFZFkRtP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kuota-bimbingan/kp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eeM52cz66ipN4oqF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kuota-bimbingan/skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yxo77vabRWTfWlsE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/developer/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0Sam6CTxpi6GvcbN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rlU95rBKGJ7WJAcR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/persetujuan-koordinator' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zAW2TZ4NLYjpEgRD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayat-koordinator' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B3KZoMJ6eM09aqFI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/peminjaman-plp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'peminjamanplp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/riwayat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'riwayatplp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/stok-plp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'stokplp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/stokbaru-plp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'stokbaruplp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/inventaris/tambahbarang-plp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tambahbarangplp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/persetujuan-kaprodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ceDfDANGnCdo8oHd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/riwayat-kaprodi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aA5080NnhBrnYubg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kp-skripsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s8X5wUA8bYyNkWHw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/balasan-kp/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cZF4eUk1Sm9iS7T7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/balasan-kp/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l0H4UXIMRfgD94Sm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rzcTwIP50GVdScnz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kerja-praktek/nilai-keluar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tkkIJemMnRjoCead',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/skripsi/nilai-keluar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0eJbP3mRLC9gxTad',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/p(?|e(?|n(?|gumuman/([^/]++)(?|(*:39)|/(?|edit(*:54)|public(*:67))|(*:75))|yerahan\\-buku\\-skripsi/create/([^/]++)(?|(*:124))|daftaran(?|\\-kp/approve/([^/]++)(*:165)|kp\\-koordinator/approve/([^/]++)(*:205))|ilaian\\-(?|kp(?|/(?|create/([^/]++)(*:249)|edit/([^/]++)(*:270)|approve/([^/]++)(*:294)|tolak/([^/]++)(*:316))|\\-pe(?|mbimbing(?|/(?|create/([^/]++)(*:362)|edit/([^/]++)(*:383))|\\-penguji/edit/sama/([^/]++)(*:420))|nguji(?|/(?|create/([^/]++)(*:456)|edit/([^/]++)(*:477))|\\-pembimbing\\-sama/create/([^/]++)(*:520))))|s(?|empro(?|/(?|c(?|reate/([^/]++)(*:565)|ek\\-nilai/([^/]++)(*:591))|edit/([^/]++)(*:613)|approve/([^/]++)(*:637)|gagal/([^/]++)(*:659)|riwayat\\-judul/([^/]++)(*:690)|beritaacara\\-sempro/([^/]++)(*:726))|\\-pe(?|mbimbing/(?|create/([^/]++)(*:769)|edit/([^/]++)(*:790))|nguji/(?|create/([^/]++)(*:823)|edit/([^/]++)(*:844))))|kripsi(?|/(?|c(?|reate/([^/]++)(*:886)|ek\\-nilai/([^/]++)(*:912))|edit/([^/]++)(*:934)|approve/([^/]++)(*:958)|tolak/([^/]++)(*:980)|riwayat\\-judul/([^/]++)(*:1011)|draft\\-ba/([^/]++)(*:1038)|beritaacara\\-skripsi/([^/]++)(*:1076))|\\-pe(?|mbimbing/(?|create/([^/]++)(*:1120)|edit/([^/]++)(*:1142))|nguji/(?|create/([^/]++)(*:1176)|edit/([^/]++)(*:1198)))))))|r(?|mohonan(?|kp(?|/(?|create/([^/]++)(?|(*:1254))|pembimbing/approve/([^/]++)(*:1291))|\\-koordinator/pembimbing/tolak/([^/]++)(*:1340))|\\-kp/detail/(?|pembimbing/([^/]++)(*:1384)|([^/]++)(*:1401)))|panjang(?|an(?|\\-(?|revisi/(?|create/([^/]++)(?|(*:1460))|pembimbing/(?|approve/([^/]++)(*:1500)|tolak/([^/]++)(*:1523))|detail/([^/]++)(*:1548)|k(?|oordinator/(?|approve/([^/]++)(*:1591)|tolak/([^/]++)(*:1614))|aprodi/(?|approve/([^/]++)(*:1650)|tolak/([^/]++)(*:1673))))|1/detail/([^/]++)(*:1702)|2/detail/([^/]++)(*:1728))|1(?|\\-skripsi/create/([^/]++)(?|(*:1770))|/(?|pembimbing/(?|approve/([^/]++)(*:1814)|tolak/([^/]++)(*:1837))|kaprodi/(?|approve/([^/]++)(*:1874)|tolak/([^/]++)(*:1897))))|2(?|\\-skripsi/create/([^/]++)(*:1938)|/(?|pembimbing/(?|approve/([^/]++)(*:1981)|tolak/([^/]++)(*:2004))|k(?|oordinator/(?|approve/([^/]++)(*:2048)|tolak/([^/]++)(*:2071))|aprodi/(?|approve/([^/]++)(*:2107)|tolak/([^/]++)(*:2130))))))|\\-revisi/spesial/kaprodi/([^/]++)(*:2177))|setujuan(?|/admin/detail/(?|usulan(?|kp/([^/]++)(*:2235)|judul/([^/]++)(*:2258))|kpti10/([^/]++)(*:2283)|s(?|empro/([^/]++)(*:2310)|idang/([^/]++)(*:2333)))|\\-k(?|oordinator/detail/([^/]++)(*:2376)|aprodi/detail/([^/]++)(*:2407))|kp\\-k(?|oordinator/(?|approve/([^/]++)(*:2455)|tolak/([^/]++)(*:2478))|aprodi/(?|approve/([^/]++)(*:2514)|tolak/([^/]++)(*:2537)))|s(?|kripsi\\-k(?|oordinator/(?|approve/([^/]++)(*:2594)|tolak/([^/]++)(*:2617))|aprodi/(?|approve/([^/]++)(*:2653)|tolak/([^/]++)(*:2676)))|empro\\-kaprodi/(?|approve/([^/]++)(*:2721)|tolak/([^/]++)(*:2744))))|baikan\\-(?|kp/([^/]++)(*:2778)|s(?|empro/([^/]++)(*:2805)|kripsi/([^/]++)(*:2829))|penguji(?|kp/([^/]++)/([^/]++)(*:2869)|s(?|empro/([^/]++)/([^/]++)(*:2905)|kripsi/([^/]++)/([^/]++)(*:2938))))|daftarankp\\-koordinator/tolak/([^/]++)(*:2988)))|ro(?|gram\\-mbkm/([^/]++)(*:3023)|di/(?|edit/([^/]++)(*:3051)|([^/]++)(*:3068)|riwayat(*:3084))|fil\\-dosen/editfotodsn/([^/]++)(?|(*:3128)))|lp/edit/([^/]++)(?|(*:3158)))|/d(?|istribusi\\-dokumen/(?|dokumen/(?|([^/]++)(?|(*:3218)|/edit(*:3232)|(*:3241))|mention/([^/]++)/([^/]++)(?|(*:3279))|([^/]++)/public(*:3304))|s(?|urat(?|cuti/([^/]++)(?|(*:3341)|/(?|edit(*:3358)|a(?|cc/admin(*:3379)|pprove(*:3394))|download(*:3412)|reject(*:3427)|public(*:3442))|(*:3452))|/([^/]++)(?|(*:3474)|/(?|edit(*:3491)|acc(?|/(?|staf(?|prodi(*:3522)|Jurusan(*:3538))|kaprodi(*:3555))|(*:3565))|ubah\\-tujuan(*:3587)|done(*:3600)|reject(*:3615)|public(*:3630))|(*:3640)))|ertifikat/([^/]++)(?|(*:3672)|/(?|edit(*:3689)|reject(*:3704)|acc/(?|admin(*:3725)|kajur(*:3739)|sign(*:3752))|completion(?|(*:3775)))|(*:3786))))|e(?|tail(?|\\-(?|kp/([^/]++)(*:3825)|s(?|empro/([^/]++)(*:3852)|kripsi(?|/([^/]++)(*:3879)|\\-final/([^/]++)(*:3904))|urat\\-permohonan\\-(?|pengajuan\\-topik\\-skripsi/([^/]++)(*:3969)|kp/([^/]++)(*:3989)))|undangan\\-(?|kp/([^/]++)(*:4024)|s(?|empro/([^/]++)(*:4051)|idang/([^/]++)(*:4074)))|form\\-pe(?|ngajuan\\-topik\\-skripsi/([^/]++)(*:4128)|rmohonan\\-kp/([^/]++)(*:4158)))|/(?|kuota\\-bimbingan/(?|kp/([^/]++)(*:4204)|skripsi/([^/]++)(*:4229))|lulus\\-bimbingan/(?|kp/([^/]++)(*:4270)|skripsi/([^/]++)(*:4295))))|veloper/edit/([^/]++)(?|(*:4331)))|aftar(?|\\-s(?|em(?|kp/(?|create/([^/]++)(?|(*:4385))|detail/(?|pembimbing/([^/]++)(*:4424)|([^/]++)(*:4441)))|pro/(?|create/([^/]++)(?|(*:4477))|detail/(?|([^/]++)(*:4505)|pembimbing/([^/]++)(*:4533))|koordinator/(?|tolak/([^/]++)(*:4572)|approve/([^/]++)(*:4597))))|idang/(?|create/([^/]++)(?|(*:4636))|detail/(?|([^/]++)(*:4664)|pembimbing/([^/]++)(*:4692))|k(?|oordinator/(?|tolak/([^/]++)(*:4734)|approve/([^/]++)(*:4759))|aprodi/(?|tolak/([^/]++)(*:4793)|approve/([^/]++)(*:4818)))))|s(?|empro/(?|pembimbing(?|1/(?|approve/([^/]++)(*:4878)|tolak/([^/]++)(*:4901))|2/(?|approve/([^/]++)(*:4932)|tolak/([^/]++)(*:4955)))|k(?|oordinator/(?|approve/([^/]++)(*:5000)|tolak/([^/]++)(*:5023))|aprodi/(?|approve/([^/]++)(*:5059)|tolak/([^/]++)(*:5082))))|idang/(?|pembimbing(?|1/(?|approve/([^/]++)(*:5137)|tolak/([^/]++)(*:5160))|2/(?|approve/([^/]++)(*:5191)|tolak/([^/]++)(*:5214)))|koordinator/(?|approve/([^/]++)(*:5256)|tolak/([^/]++)(*:5279)))))|osen/(?|edit/([^/]++)(?|(*:5316))|([^/]++)(*:5334)))|/s(?|e(?|m(?|ester/([^/]++)(?|/edit(*:5380)|(*:5389))|kp/admin/(?|approve/([^/]++)(*:5427)|tolak/([^/]++)(*:5450))|pro/undur/(?|admin/([^/]++)(?|(*:5490)|(*:5499))|koordinator/([^/]++)(?|(*:5532)|(*:5541))))|rtifikat/([^/]++)(?|(*:5573)|/download(*:5591))|lesais(?|em(?|inar\\-kp/pembimbing/(?|approve/([^/]++)(*:5654)|tolak/([^/]++)(*:5677))|pro/pembimbing/(?|approve/([^/]++)(*:5721)|tolak/([^/]++)(*:5744)))|idang/pembimbing/(?|approve/([^/]++)(*:5791)|tolak/([^/]++)(*:5814))))|idang/(?|admin/perpanjangan\\-(?|1/detail/([^/]++)(*:5875)|2/detail/([^/]++)(*:5901))|undur/(?|admin/([^/]++)(?|(*:5937)|(*:5946))|koordinator/([^/]++)(?|(*:5979)|(*:5988))))|urat(?|\\-permohonan(?|\\-(?|kp/([^/]++)(*:6038)|pengajuan\\-topik\\-skripsi/([^/]++)(*:6081))|kp/([^/]++)(*:6102))|perusahaan/detail/pembimbingprodi/([^/]++)(*:6154)))|/l(?|ogo/([^/]++)(?|/edit(*:6190)|(*:6199))|ewat\\-batas\\-(?|s(?|idang/hapus/([^/]++)(*:6249)|kripsi/hapus/([^/]++)(*:6279))|revisi\\-spesial/hapus/([^/]++)(*:6319)|penyerahan\\-skripsi/hapus/([^/]++)(*:6362)|kp/(?|hapus/([^/]++)(*:6391)|pembimbing/hapus/([^/]++)(*:6425))|balasan/hapus/([^/]++)(*:6457)))|/m(?|bkm/(?|uploaded/([^/]++)(*:6497)|([^/]++)/sertifikat/create(*:6532)|s(?|ertifikat/create/([^/]++)/delete(*:6577)|taff/approve/([^/]++)(*:6607))|logbook/([^/]++)(*:6633)|undur\\-diri/([^/]++)(?|(*:6665))|p(?|enilaian\\-mbkm/([^/]++)/delete(*:6709)|rodi/(?|approve(?|/([^/]++)(*:6745)|konversi/([^/]++)(?|(*:6774))|pengunduran/([^/]++)(*:6804))|tolak(?|usulan/([^/]++)(*:6837)|konversi/([^/]++)(*:6863))))|([^/]++)(?|/(?|donwload\\-konversi\\-pdf(*:6913)|logbook(*:6929))|(*:6939)))|a(?|tkul/([^/]++)(?|/edit(*:6975)|(*:6984))|hasiswa/(?|edit/([^/]++)(?|(*:7021))|([^/]++)(*:7039))))|/b(?|alasan(?|kp/(?|create/([^/]++)(?|(*:7089))|koordinator/(?|approve/([^/]++)(*:7130)|tolak/([^/]++)(*:7153)))|\\-kp/detail/([^/]++)(*:7184))|erita(?|acara\\-kp/([^/]++)(*:7220)|\\-acara\\-final/([^/]++)(*:7252))|uk(?|ti\\-buku\\-skripsi/(?|detail/([^/]++)(*:7303)|riwayat/detail/([^/]++)(*:7335))|u\\-skripsi/koordinator/(?|approve/([^/]++)(*:7387)|tolak/([^/]++)(*:7410))))|/k(?|p(?|ti10(?|\\-kp/(?|create/([^/]++)(?|(*:7464))|detail/(?|([^/]++)(*:7492)|riwayat/([^/]++)(*:7517)))|/(?|koordinator/(?|approve/([^/]++)(*:7563)|tolak/([^/]++)(*:7586))|detail/(?|pembimbingprodi/([^/]++)(*:7630)|riwayat/pembimbingprodi/([^/]++)(*:7671))))|\\-skripsi/(?|pe(?|rsetujuan/(?|perpanjangan\\-(?|revisi/([^/]++)(*:7746)|1/([^/]++)(*:7765)|2/([^/]++)(*:7784))|s(?|uratperusahaan/([^/]++)(*:7821)|em(?|pro/([^/]++)(*:7847)|kp/([^/]++)(*:7867))|idang/([^/]++)(*:7891))|kpti10/([^/]++)(*:7916)|usulan(?|judul/([^/]++)(*:7948)|kp/([^/]++)(*:7968))|bukti\\-buku\\-skripsi/([^/]++)(*:8007))|mbimbing/(?|perpanjangan\\-(?|1/([^/]++)(*:8056)|2/([^/]++)(*:8075)|revisi/([^/]++)(*:8099))|bukti\\-buku\\-skripsi/([^/]++)(*:8138)))|riwayat/pembimbing/bukti\\-buku\\-skripsi/([^/]++)(*:8197)))|onsentrasi/(?|edit/([^/]++)(?|(*:8238))|([^/]++)(*:8256))|apasitas\\-bimbingan/edit/([^/]++)(?|(*:8302)))|/inventaris/(?|delete(?|/([^/]++)(*:8346)|\\-dosen/([^/]++)(*:8371)|barang(?|/([^/]++)(*:8398)|\\-plp/([^/]++)(*:8421)))|edit(?|/([^/]++)(*:8448)|\\-dosen/([^/]++)(*:8473)|barang(?|/([^/]++)(*:8500)|\\-plp/([^/]++)(*:8523)))|update(?|/([^/]++)(*:8552)|\\-dosen/([^/]++)(*:8577)|barang(?|/([^/]++)(*:8604)|\\-plp/([^/]++)(*:8627)))|setuju(?|/([^/]++)(*:8656)|\\-plp/([^/]++)(*:8679))|tolak(?|/([^/]++)(*:8706)|\\-plp/([^/]++)(*:8729))|kembali(?|/([^/]++)(*:8758)|\\-plp/([^/]++)(*:8781)))|/u(?|s(?|ul(?|an(?|kp/(?|admin/(?|approve/([^/]++)(*:8842)|tolak/([^/]++)(*:8865))|pembimbing/(?|approve/([^/]++)(*:8905)|tolak/([^/]++)(*:8928))|k(?|oordinator/(?|approve/([^/]++)(*:8972)|tolak/([^/]++)(*:8995))|aprodi/(?|approve/([^/]++)(*:9031)|tolak/([^/]++)(*:9054))))|\\-semkp/(?|pembimbing/(?|approve/([^/]++)(*:9107)|tolak/([^/]++)(*:9130))|k(?|oordinator/(?|approve/([^/]++)(*:9174)|tolak/([^/]++)(*:9197))|aprodi/(?|approve/([^/]++)(*:9233)|tolak/([^/]++)(*:9256))))|/detail/(?|([^/]++)(*:9287)|pembimbingprodi/([^/]++)(*:9320)))|judul/(?|detail/(?|pembimbing2/([^/]++)(*:9370)|([^/]++)(*:9387)|pembimbing/([^/]++)(*:9415))|pembimbing(?|1/(?|approve/([^/]++)(*:9459)|tolak/([^/]++)(*:9482))|2/(?|approve/([^/]++)(*:9513)|tolak/([^/]++)(*:9536)))|k(?|oordinator/(?|approve/([^/]++)(*:9581)|tolak/([^/]++)(*:9604))|aprodi/(?|approve/([^/]++)(*:9640)|tolak/([^/]++)(*:9663)))))|er/(?|edit/([^/]++)(?|(*:9698))|([^/]++)(*:9716)))|pdate/([^/]++)(*:9741)|ndangan\\-(?|kp/([^/]++)(*:9773)|s(?|empro/([^/]++)(*:9800)|idang/([^/]++)(*:9823))))|/r(?|ole/(?|edit/([^/]++)(?|(*:9863))|([^/]++)(*:9881))|e(?|set\\-password/(?|mahasiswa/([^/]++)(*:9930)|dosen/([^/]++)(*:9953)|user/([^/]++)(*:9975))|visi\\-(?|proposal/create/([^/]++)(*:10018)|skripsi/create/([^/]++)(*:10051))))|/nilai(?|\\-(?|kp/([^/]++)(*:10089)|s(?|empro(?|/([^/]++)(*:10120)|\\-pe(?|mbimbing/([^/]++)/([^/]++)(*:10163)|nguji/([^/]++)/([^/]++)(*:10196)))|kripsi(?|/([^/]++)(*:10226)|\\-pe(?|mbimbing/([^/]++)/([^/]++)(*:10269)|nguji/([^/]++)/([^/]++)(*:10302)))))|jurnal/create/([^/]++)(*:10338)|kpkeluar/koordinator/approve/([^/]++)(*:10385)|skripsikeluar/koordinator/approve/([^/]++)(*:10437))|/c(?|atatans(?|empro/create/([^/]++)(*:10484)|kripsi/create/([^/]++)(*:10516))|eknilai\\-kp/([^/]++)(*:10547))|/form\\-(?|kp/(?|([^/]++)(*:10582)|edit/(?|koordinator/([^/]++)(?|(*:10623)|(*:10633))|([^/]++)(?|(*:10655)|(*:10665))))|s(?|empro/(?|edit/([^/]++)(?|(*:10707))|([^/]++)(*:10726)|edit/koordinator/([^/]++)(?|(*:10764)))|kripsi/(?|edit/([^/]++)(?|(*:10802))|([^/]++)(*:10821)|edit/koordinator/([^/]++)(?|(*:10859))))|pe(?|rmohonan\\-kp/([^/]++)(*:10898)|ngajuan\\-topik\\-skripsi/([^/]++)(*:10940))))/?$}sDu',
    ),
    3 => 
    array (
      39 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      54 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      67 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.detail.public',
          ),
          1 => 
          array (
            0 => 'encryptId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      75 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pengumuman.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      124 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tAhbOoy7c7iZR0Zy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a1hcBrHOM55JulnY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A1FOTh1pMZPORWWe',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      205 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NC6D3ATCDyl0x55U',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GxlCybufRaM7rqHK',
          ),
          1 => 
          array (
            0 => 'penjadwalan_kp',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      270 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i1K9t10laI9z7BCx',
          ),
          1 => 
          array (
            0 => 'penjadwalan_kp',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      294 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cPo53PT99rlwn6r7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RhFDi3yxXGxwfU46',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      362 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nFduxF7FxWlmTqTQ',
          ),
          1 => 
          array (
            0 => 'penjadwalan_kp',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      383 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0bjzSZLxT6lY3i6I',
          ),
          1 => 
          array (
            0 => 'penilaian_kp_pembimbing',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      420 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dxb2UxqCSLDHpdVI',
          ),
          1 => 
          array (
            0 => 'penilaian_kp_penguji',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      456 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dD9s818vNkcZWh0w',
          ),
          1 => 
          array (
            0 => 'penjadwalan_kp',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::okI6CBCp9xaYj25W',
          ),
          1 => 
          array (
            0 => 'penilaian_kp_penguji',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      520 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8xu8hiT3qkvUObOw',
          ),
          1 => 
          array (
            0 => 'penjadwalan_kp',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      565 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Qqak8v2duCKRpaa9',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      591 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6mhsQIyMPHnKkfim',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      613 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dk6FqIlXHIlSlYqg',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1g1joKjxCIvS9lB4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      659 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::avhYFTLUbVw0axg0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      690 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SW5hpiZLIZxj5oTv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      726 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h7IAlTpn005symty',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      769 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LrNDDLpsmryc2dn1',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      790 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UjKKXOpBFnMDLSuc',
          ),
          1 => 
          array (
            0 => 'penilaian_sempro_pembimbing',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      823 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1E7eW7ta6dSPR9S3',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      844 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hxOms3bSZzeskkuf',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      886 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ezk7leGzcd9uhOTK',
          ),
          1 => 
          array (
            0 => 'penjadwalan_skripsi',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      912 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IEHubupd7ABgIS49',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      934 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vH4FZSQWFHH1HIrf',
          ),
          1 => 
          array (
            0 => 'penjadwalan_skripsi',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      958 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J86P61EcTyAU6y64',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      980 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u23GYRHy22FmwdyH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1011 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YhdGtOhb7WHEVoPc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1038 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jiqks2ID86QieXhR',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1076 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vIBXpgCZk8KfCYmk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1120 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lzTFk15KvpGyhRyi',
          ),
          1 => 
          array (
            0 => 'penjadwalan_skripsi',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1142 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5Kv71rr6SoLt2ieR',
          ),
          1 => 
          array (
            0 => 'penilaian_skripsi_pembimbing',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1176 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q5EBSKypAcNeQNsv',
          ),
          1 => 
          array (
            0 => 'penjadwalan_skripsi',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1198 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7lrJMbjm39VnvISf',
          ),
          1 => 
          array (
            0 => 'penilaian_skripsi_penguji',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1254 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uyfJwcNp5qc3hQxK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::llLo0bUmaOMQMltU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1291 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1quKOQhaiPMu4N7F',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1340 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hGQcn3DFGfywJ4JS',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1384 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZiI6wWiYAJpUkb4q',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1401 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GW3Mw8zeaxq9ZWB1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1460 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YAf6TFH82P9TKXZz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MYLbjrX48R3573FU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1500 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::doqASyc3koOjqPBA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1523 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jafmQxRcCpeftfDz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1548 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kU1VDX6KjUM45QZ5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1591 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BM7ndPt5rD8DRk95',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1614 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OaRr3uXS770nYSau',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1650 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FIaHvLH3dZP4d5DK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1673 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J8cZQySQd152sMsz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1702 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h68B1iel9BB87pyF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1728 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a2Z76hE6VXkYdNl5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1770 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0Y89AcP1oDjcWEc3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iRTdxVkTcCLljJSp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1814 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0hzPmM39uo0jbWNm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S3vtXDdifAt7lcrJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1874 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jcT6tKOACrdunsgw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1897 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AOILtKCqiXKJ4vGU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1938 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uOnFYqACRy15Mxe4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1981 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RUgjSKOm0dMiMlZ8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2004 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PfueS5oWD4gtiu5b',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2048 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WBX6vMrEzZl0tCra',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2071 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H8zYSwnaw3rEZ7f7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2107 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mZtdulmsM46IQjfn',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2130 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pzXoo0e5hR8MyKa9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2177 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k8nJrJIbDVbg8idQ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hpHLm4f1sXohcIeQ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2258 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pMOuAt2SxPgYQDI0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2283 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gLdgL6TJMOX8fmYu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2310 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sDnSCTKJJQgYRjI7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2333 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Blf5AtLeYZUJ1bfM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2376 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HE1jtUEx9eMtmzH9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JND1NYmXBxxT5JID',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2455 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WsfFBWb6Vqo88l9K',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2478 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::agP4O9fILYBfJX8P',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2514 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l1wWeIz5fgbKp0gq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2537 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pNd1fYXb46DUFWiq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2594 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R2v8JOy0SSEqVoUK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2617 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::399Hb1hGq4ruUkAu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2653 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sguXW3GZgw2fvxEJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2676 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c0K51UMQ5GCvPbUX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2721 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mfTBpVRnq54yqifz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2744 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mUMSa1IT5dryHDXk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2778 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7ReqANEZDnIiNtoP',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2805 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hID5JDjdxUChYeYw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2829 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YA2383SiQ0exXUKo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2869 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::86ItSwqjz52a39fc',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'penguji',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2905 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::88cvocQhOZxlGh7i',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'penguji',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2938 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q4rB1I1jdV0MMyEu',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'penguji',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2988 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CFtbwC1QdOLyAmdX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3023 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program-mbkm.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3051 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K1FYuCBNmGAMqiwh',
          ),
          1 => 
          array (
            0 => 'prodi',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3068 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O5yQSlxuV9C9q5l6',
          ),
          1 => 
          array (
            0 => 'prodi',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3084 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KZVonX9xTbSQhEF7',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3128 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b2px3neHsvFkmB82',
          ),
          1 => 
          array (
            0 => 'dosen',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lD6vBCfCge3jhJIi',
          ),
          1 => 
          array (
            0 => 'dosen',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3158 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0gr2ZI9hEfPtz6XK',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FYno8mc3HgHFjKOs',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3218 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dokumen.detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3232 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dokumen.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3241 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dokumen.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'dokumen.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dokumen.mention.accept',
          ),
          1 => 
          array (
            0 => 'dokumen_id',
            1 => 'user_mentioned',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'dokumen.mention.delete',
          ),
          1 => 
          array (
            0 => 'dokumen_id',
            1 => 'user_mentioned',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3304 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dokumen.detail.public',
          ),
          1 => 
          array (
            0 => 'encryptId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3341 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3358 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3379 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.acc.admin',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3394 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.approve',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3412 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.download',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3427 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.reject',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3442 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.detail.public',
          ),
          1 => 
          array (
            0 => 'encryptId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3452 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'suratcuti.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3474 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'surat.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3491 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.acc.stafprodi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3538 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.acc.stafjurusan',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3555 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.acc.kaprodi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3565 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.accept',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3587 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.edit.tujuan',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3600 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.done',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3615 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.reject',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3630 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.detail.public',
          ),
          1 => 
          array (
            0 => 'encryptId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3640 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3672 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3689 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3704 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.reject',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3725 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.acc.admin',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3739 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.acc.kajur',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3752 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.acc.sign',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3775 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.make',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.completion',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3786 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3825 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yqKTtMGl109VJfaN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3852 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H8ZStgAdtDLcIv9M',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3879 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RgQRMloG4raWar6z',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3904 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qUDXxBR8GC7Cj1PX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3969 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GUEJApLiwfxKZo2h',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3989 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g7wOco6NSMNWwoS2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4024 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sbtJzzqAw2BrRXYo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4051 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xHmyoBJ9iQduTjej',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4074 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iBtsSlKCj0yVzZtx',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4128 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yEtiqAuJusrTITcO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4158 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CE7NAwvfY3bFtxcT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4204 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jJTjQniETDcX6lEq',
          ),
          1 => 
          array (
            0 => 'nip',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4229 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ja45FtmMpZPYqF35',
          ),
          1 => 
          array (
            0 => 'nip',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4270 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gQqG7b2A2GhtmvvU',
          ),
          1 => 
          array (
            0 => 'nip',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4295 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::96klo3NyiQNSmPaz',
          ),
          1 => 
          array (
            0 => 'nip',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DSQWi8tKlERM8TnY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wYWQI5DL84AZvojI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4385 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IooiawCcuqf4gAqh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uXTG6sfXjZUOffTI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4424 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nqlsKzUZAlGLqOdP',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4441 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IiTSkmNlFOQ9YXYB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kfhoPbxIfCFJQjTa',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4wdQiIyTEfjtCCR7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4505 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6SDb5BJuwjgiHq5B',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4533 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZZrKMRoFHW9AAFjT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4572 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::E2Imzwp1D2TxdS33',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4597 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QVuwikqi6PMBxXPl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4636 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PQ9Foq6NnxZrtnD2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::taYlupS6jrJ0OHYX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4664 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AAgOtqnHXgTIOOc3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4692 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6Y2HtojvX1IBWvRD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4734 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SpOmPEB05jSPRz0K',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4759 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A9cKDztMThpuPXCi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4793 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oNoBH0ofSI2gIoxY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4818 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sAmG9F92EEscgD6c',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4878 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CTZuEHmBPOzo3rNh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4901 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7ZyDu5fGCqBXqGJ3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4932 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6TnU3sx5JD1AACRS',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4955 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GeedpaI37KpTJASt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5000 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zilHPR2WRgVEBEjE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5023 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3day3PNbJkw72eEw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5059 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cKeHkndzFhfxmaSd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5082 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2pHy6FN5VzW2YJ94',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5137 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ODswrlC8Yk1OsKKX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5160 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ora5fQ6rHkCHr01t',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5191 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C401GylC6m8zdsyw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5214 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eynFKqiJXpqyEQO6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5256 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Uy92MJ6KDFWTaqd9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lrNUTP5tx3mGvpBW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6ME43ts2dSEJfTrB',
          ),
          1 => 
          array (
            0 => 'dosen',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d1hMOQ4xM1ouCG44',
          ),
          1 => 
          array (
            0 => 'dosen',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5334 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KmLUUqojnRgbGbAJ',
          ),
          1 => 
          array (
            0 => 'dosen',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5380 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5389 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'semester.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5427 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ojr18AeXbGZOiZeQ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5450 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uuq8f0tkNdwF81xK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QvM6bK8JXwcWEFeP',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5499 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kuSCtPFAKo6vs8HL',
          ),
          1 => 
          array (
            0 => 'alasan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5532 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6PwpNQ68VHBXoIbf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5541 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dLbrN6XrDxF7lXw2',
          ),
          1 => 
          array (
            0 => 'alasan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5573 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.penerima',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5591 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sertif.download',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5654 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mVItVN6tq4IEE63H',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5677 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VHDvrcBXlBoF1sX1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5721 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HiqfJDobZuGmITPb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5744 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nyGZDiIDZ4YJijx9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5791 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::88Gx8QyAppmbtzec',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5814 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zyCC4iiH44QIoOKA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5875 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4pFuztB9HCJI9jge',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5901 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WFiKrVYlGqLPGEcs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5937 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jOzbPyhgXcHsBEhs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5946 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gvH8jvAtLIYHShxD',
          ),
          1 => 
          array (
            0 => 'alasan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5979 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2LOgLDY3T0v7FpYI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5988 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ua2rcOtFxyUIzNPc',
          ),
          1 => 
          array (
            0 => 'alasan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6038 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7kucqnpoJjhIUDHN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6081 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j2UJVwI79amoFeeN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6102 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LnpZV7vOfvUKV3vW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YJUGLDKknXuaKMO1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6190 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logo.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      6199 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logo.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'logo.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ETaD3HMZrSLwlEGY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Xee2kXeiQgpldOv5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6319 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rug6goBBm0RXrt7Y',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6362 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bnjfNPy8DDrbdJax',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6391 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JMZ18gbskbNEOedO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6425 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aekpSX1uFZQF1KMl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6457 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LXvpsKEZ2sTRd6v5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6497 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.uploaded',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6532 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.sertif.create',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      6577 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.sertif.destroykonversi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      6607 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.staff.approve',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.logbook.store',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6665 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.undurdiri',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.undurdiri.store',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6709 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'penilaian.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      6745 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.prodi.approveusulan',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6774 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.prodi.konversi',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.prodi.approvekonversi',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6804 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.prodi.approvepengunduran',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.prodi.tolakusulan',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6863 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.prodi.tolakkonversi',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6913 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.pdf',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      6929 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.logbook',
          ),
          1 => 
          array (
            0 => 'mbkmId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      6939 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.detail',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'mbkm.destroy',
          ),
          1 => 
          array (
            0 => 'mbkm',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6975 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'matkul.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      6984 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'matkul.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'matkul.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7021 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CGPThOrnxtS6Jiwm',
          ),
          1 => 
          array (
            0 => 'mahasiswa',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Suwayubo794iOQtZ',
          ),
          1 => 
          array (
            0 => 'mahasiswa',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7039 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j8KJVlmiDp6wtfG8',
          ),
          1 => 
          array (
            0 => 'mahasiswa',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7089 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XaQIbrKrRxxpmHfx',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V07jKgxg5TcVwWWk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7130 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ckOIDdcbc2bFckaE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7153 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XRJVBVelG0Z0uj5u',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7184 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PKO5D4XN6E5YQbsU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7220 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::amSfaGNCuj6iOSV6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7252 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LHAqCrI9BhjSlYda',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7303 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y0ByEiW1BIFl3N2y',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7335 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f1AWN9WiH8EfPHNd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z8wIl422kuPd7H3L',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7410 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fhj11JNDWxq43dWh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7464 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N0gaBLd3bXMyg6Qb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ik2S5mmqBTyBku8j',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7492 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OeWIUgHzi7bbsSaa',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7517 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HlUzqLt3Lr7gFwlX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7563 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::slyQmZDMviIJyzB6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7586 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y3o8nPcyjKttPEo1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7630 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EnW6nJKwFxpWBalr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7671 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0GNSkXOtO8HaR72W',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7746 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ot87QexPRbyelhaz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7765 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3cHWOSgu6RYTv70G',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7784 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CYS7EwMbw2UQNpch',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7821 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lhdkSyZ6ZReZezd9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7847 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Lx3MrE37oAiQoyuX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7867 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hWIvouJmtyim78OA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7891 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3NUJx2tCmGEYkqvq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7916 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mEchUf3Nt2LalrK8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7948 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CJudups35SgA7KSB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7968 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QPt2VzFcncQMFlD3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8007 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fAiOmVC5G8ncgvXN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8056 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BnOXCwywghAGcG4i',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8075 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lfJ2iN2b3QDFX9U1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8099 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z3midKa3EPVoEaIV',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8138 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fXuRHxuI80UgKjDH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8197 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LtlEk4L2UeLTEF2J',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8238 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PUDfRtwjBDZGh9KE',
          ),
          1 => 
          array (
            0 => 'konsentrasi',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t9y9YiAUWTr0Ci1F',
          ),
          1 => 
          array (
            0 => 'konsentrasi',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8256 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6LhUNl79wEiZThTH',
          ),
          1 => 
          array (
            0 => 'konsentrasi',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8302 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Npkjf7AEtPkmpgA6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tdHy5Bi3WHoqIYyt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8346 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4kgI3UhT4zSzDYXM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8371 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::es75ObJuBRrOkW5Y',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8398 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'deletebarang',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8421 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'deletebarangplp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8448 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zURyy3fi0GmDTNau',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8473 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UJiDbZy6zAKqd7Qf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8500 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'editbarang',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8523 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'editbarangplp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8552 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zqOr0w8zeIG4zaL1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8577 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s7773THJ9zDFXAdS',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8604 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'updatebarang',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8627 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'updatebarangplp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8656 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EU1kwBiEXhkCwfnz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8679 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4osUpkvmnsbyPoXW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8706 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X6E1dk97vOAbwBJ4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8729 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eXavYfTpRd78YizB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8758 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KHaA2VPCsPA0HaBm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8781 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IfKP9fsWnXMwmEWG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8842 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X5JsUX8Aiv1IxEAv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8865 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mR9LOxyQFf9yappU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8905 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kNnW1HtgcDQCFTfE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8928 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5HGdXbVE8gg1smDO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8972 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5jjrNreuafV0Qw26',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8995 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XQpQkgNtdbZ0XpEt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9031 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5a23pASd9QuIbXcB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9054 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hnfLRxRkzCrjwSBU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9107 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jEUoxgx9UvINRuIO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9130 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::swndNnow9sV1pMg7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9174 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bVDvWO46sLsgxrBZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9197 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7fIdGoZMAZFmtwAO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9233 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ML0LUMp0faiYdNW7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9256 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f1Yn2TcDoSoFDp4G',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9287 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7xQjCvNh767N6glI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9320 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UtZS23wHgOWMsobh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9370 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pmf6L7HwiCk0giTh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JPYyHK8llH6ujZWi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9415 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::awEiMjXK9JFq6cmO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9459 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QvtamA30UWsdITZP',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9482 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xrHfQBzSZ2w846eo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9513 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IKlXcdAxcLQUFg0F',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9536 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D8sYP610HEifmBDf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9581 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::194cKmfigiwUkcwi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9604 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PMhE4vSzfzdgYaa9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9640 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M2Kz8xH7AQC3Gwcm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9663 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QCDFWfjsYjvP0nTL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9698 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M6SAMKuA1TyFxnIs',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BkZ7RVSGGINOeHmd',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9716 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pUhHna035I2dCVcY',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9741 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'prodi.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9773 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1AmTsjUS4sgU9c54',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9800 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XcoERNnuoslulDBp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9823 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3UQ0zLlk7VG6AYjl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9863 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tCPjHAxVLLEUZdeD',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lhI53aBQ5JeKBjUh',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9881 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zfChNjHCxfImhsnE',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9930 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MBovJB2TDCYcwEvC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9953 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eX4WAfJ0ojEeTLug',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      9975 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bBx6PuwkVjN5iqCF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10018 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s41WbHWwr167y88y',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10051 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2JEcBNTnAhr5P3Id',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10089 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QssGXAkciQijRU8Q',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10120 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cJc6ZhF7dQ1FE2s3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10163 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mz1ioYWew3ANNcDu',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'pembimbing',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10196 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pOLJynAuIhv9Qj3w',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'penguji',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10226 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lpGa05kxVnWopWGv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10269 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ntV1Ypou0M2l4cG0',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'pembimbing',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10302 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cuumAVOsa6mud9Gp',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'penguji',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10338 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lmZ5fNExZaPj0XRt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10385 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BAmtFeXE4LgZVuYh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10437 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x661nmS9RyjA73y7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10484 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IzkEy16gIyiOMreC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10516 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FZ4u1MNox87xb01X',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10547 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RPV1TVeiLU3qoKsh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10582 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uRrRJsfCEOhEoN8V',
          ),
          1 => 
          array (
            0 => 'penjadwalan_kp',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10623 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::msoNss7F6W0YEZCp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ljr5aIVf9dwWfHDS',
          ),
          1 => 
          array (
            0 => 'penjadwalan_kp',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10655 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T2guoPfWWp7WYjtc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10665 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QoskYpIX042AAcR9',
          ),
          1 => 
          array (
            0 => 'penjadwalan_kp',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10707 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RQzw7XqPAER7Vg7z',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yrSJh8AA5DM1Totp',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10726 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0edBhZSiU4TRLjPk',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10764 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a7JOc5yybo5cULUb',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lvPy0BoblaHj4GBu',
          ),
          1 => 
          array (
            0 => 'penjadwalan_sempro',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10802 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eLX5fRL6mLL2mbPC',
          ),
          1 => 
          array (
            0 => 'penjadwalan_skripsi',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1fWj4iOUzFl769VW',
          ),
          1 => 
          array (
            0 => 'penjadwalan_skripsi',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10821 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HO0IyeSxFdpppnFv',
          ),
          1 => 
          array (
            0 => 'penjadwalan_skripsi',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10859 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lEdXg50YukY6DBUv',
          ),
          1 => 
          array (
            0 => 'penjadwalan_skripsi',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a5M6KSKiuBXHdLym',
          ),
          1 => 
          array (
            0 => 'penjadwalan_skripsi',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10898 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qLOvzrn1CjHM8E6k',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      10940 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JilY1LRERrolAs1c',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::tPafewG95jjT8IvF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::tPafewG95jjT8IvF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JHPyS0XcFJgapc6s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:297:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:79:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000047b0000000000000000";}";s:4:"hash";s:44:"PyAGL0cnWfq+sO0VPawlv0limTh2cEwT62Ez8pn0pdg=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::JHPyS0XcFJgapc6s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'doc.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DistribusiDokumenController@index',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DistribusiDokumenController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'doc.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'doc.arsip' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/arsip',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DistribusiDokumenController@arsip',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DistribusiDokumenController@arsip',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'doc.arsip',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pengumuman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@index',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.arsip' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pengumuman/arsip',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@arsip',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@arsip',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.arsip',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.pengelola' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pengumuman/pengelola',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@indexPengumuman',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@indexPengumuman',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.pengelola',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.pengelola.arsip' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pengumuman/pengelola/arsip',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@arsipPengumuman',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@arsipPengumuman',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.pengelola.arsip',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pengumuman/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@create',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pengumuman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@store',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pengumuman/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@detail',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.detail',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pengumuman/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@edit',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'pengumuman/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@update',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'pengumuman/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@destroy',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dokumen.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/dokumen/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@create',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dokumen.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dokumen.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/dokumen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@store',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dokumen.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dokumen.detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/dokumen/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@detail',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dokumen.detail',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dokumen.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/dokumen/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@edit',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dokumen.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dokumen.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'distribusi-dokumen/dokumen/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@update',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dokumen.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dokumen.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'distribusi-dokumen/dokumen/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@destroy',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dokumen.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dokumen.mention.accept' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/dokumen/mention/{dokumen_id}/{user_mentioned}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenMentionController@accept',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenMentionController@accept',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dokumen.mention.accept',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dokumen.mention.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'distribusi-dokumen/dokumen/mention/{dokumen_id}/{user_mentioned}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenMentionController@destroy',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenMentionController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dokumen.mention.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@create',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/suratcuti',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@store',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@detail',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.detail',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@edit',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@update',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@destroy',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.acc.admin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/{id}/acc/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@accAdmin',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@accAdmin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.acc.admin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.approve' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/{id}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@approve',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@approve',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.approve',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/{id}/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@download',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@download',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.reject' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/{id}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@reject',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@reject',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.reject',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/surat/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@create',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@detail',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.detail',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@update',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@edit',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/surat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@store',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@destroy',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.acc.stafprodi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}/acc/stafprodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@accStafProdi',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@accStafProdi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.acc.stafprodi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.acc.kaprodi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}/acc/kaprodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@accKaprodi',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@accKaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.acc.kaprodi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.acc.stafjurusan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}/acc/stafJurusan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@accStafJurusan',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@accStafJurusan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.acc.stafjurusan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.accept' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}/acc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@accept',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@accept',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.accept',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.edit.tujuan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}/ubah-tujuan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@ubahTujuan',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@ubahTujuan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.edit.tujuan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.done' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}/done',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@done',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@done',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.done',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/surat/{id}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@reject',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@reject',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'surat.reject',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@create',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/sertifikat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@store',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@detail',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.detail',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@edit',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@update',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@delete',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@reject',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@reject',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.reject',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.acc.admin' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}/acc/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@accAdmin',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@accAdmin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.acc.admin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.acc.kajur' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}/acc/kajur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@accKajur',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@accKajur',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.acc.kajur',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.acc.sign' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}/acc/sign',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@sign',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@sign',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.acc.sign',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.make' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}/completion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@make',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@make',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.make',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.completion' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'distribusi-dokumen/sertifikat/{id}/completion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@completion',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SertifikatController@completion',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.completion',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengelola' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/pengelola',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@index',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengelola',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengelola.pengumuman' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/pengelola/pengumuman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@pengumuman',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@pengumuman',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengelola.pengumuman',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengelola.arsip' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/pengelola/arsip',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@arsip',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengelolaController@arsip',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengelola.arsip',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'semester',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@index',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'semester',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'semester/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@create',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'semester.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'semester',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@store',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'semester.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'semester/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@edit',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'semester.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'semester/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@update',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'semester.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'semester/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@delete',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SemesterController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'semester.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@index',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@create',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logo.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@store',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logo.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logo/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@edit',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logo.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'logo/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@update',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logo.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logo.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'logo/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web,dosen,mahasiswa',
          2 => 'cek-jenis-user',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@delete',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\LogoController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logo.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pengumuman.detail.public' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pengumuman/{encryptId}/public',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@detailForPublic',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PengumumanController@detailForPublic',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pengumuman.detail.public',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dokumen.detail.public' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/dokumen/{encryptId}/public',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@detailForPublic',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\DokumenController@detailForPublic',
        'namespace' => NULL,
        'prefix' => '/distribusi-dokumen',
        'where' => 
        array (
        ),
        'as' => 'dokumen.detail.public',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat.detail.public' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/surat/{encryptId}/public',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@detailForPublic',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratController@detailForPublic',
        'namespace' => NULL,
        'prefix' => '/distribusi-dokumen',
        'where' => 
        array (
        ),
        'as' => 'surat.detail.public',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suratcuti.detail.public' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'distribusi-dokumen/suratcuti/{encryptId}/public',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@detailForPublic',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\SuratCutiController@detailForPublic',
        'namespace' => NULL,
        'prefix' => '/distribusi-dokumen',
        'where' => 
        array (
        ),
        'as' => 'suratcuti.detail.public',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.penerima' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sertifikat/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PenerimaSertifikatController@show',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PenerimaSertifikatController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.penerima',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sertif.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sertifikat/{slug}/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DistribusiDokumen\\PenerimaSertifikatController@download',
        'controller' => 'App\\Http\\Controllers\\DistribusiDokumen\\PenerimaSertifikatController@download',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sertif.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/mahasiswa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@mahasiswaIndex',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@mahasiswaIndex',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/mahasiswa/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@create',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@create',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.riwayat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/mahasiswa/riwayat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@mahasiswaRiwayat',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@mahasiswaRiwayat',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.riwayat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/usulan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@store',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@store',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.uploaded' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/uploaded/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@uploaded',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@uploaded',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.uploaded',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.sertif.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/{mbkm}/sertifikat/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\SertifikatMbkmController@create',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\SertifikatMbkmController@create',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.sertif.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.sertif.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/sertifikat/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\SertifikatMbkmController@store',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\SertifikatMbkmController@store',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.sertif.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.sertif.storekonversi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/sertifikat/create/konversi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\SertifikatMbkmController@storekonversi',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\SertifikatMbkmController@storekonversi',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.sertif.storekonversi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.sertif.destroykonversi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/sertifikat/create/{id}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\SertifikatMbkmController@destroykonversi',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\SertifikatMbkmController@destroykonversi',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.sertif.destroykonversi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.logbook.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/logbook/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\LogbookController@store',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\LogbookController@store',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.logbook.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.undurdiri' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/undur-diri/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@undurDiri',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@undurDiri',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.undurdiri',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.undurdiri.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/undur-diri/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@storeUndurDiri',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@storeUndurDiri',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.undurdiri.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'penilaian.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/penilaian-mbkm/{id}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\PenilaianMbkmController@delete',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\PenilaianMbkmController@delete',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'penilaian.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.prodi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/prodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@prodiIndex',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@prodiIndex',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.prodi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.prodi.berjalan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/berjalan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@mbkmBerjalan',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@mbkmBerjalan',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.prodi.berjalan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.prodi.riwayat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/riwayat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@prodiRiwayat',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@prodiRiwayat',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.prodi.riwayat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.prodi.approveusulan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/prodi/approve/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@approveUsulan',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@approveUsulan',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.prodi.approveusulan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.prodi.konversi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/prodi/approvekonversi/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@konversi',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@konversi',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.prodi.konversi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.prodi.approvekonversi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/prodi/approvekonversi/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@approveKonversi',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@approveKonversi',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.prodi.approvekonversi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.prodi.approvepengunduran' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/prodi/approvepengunduran/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@approvePengunduran',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@approvePengunduran',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.prodi.approvepengunduran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.prodi.tolakusulan' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'mbkm/prodi/tolakusulan/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@tolakUsulan',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@tolakUsulan',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.prodi.tolakusulan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.prodi.tolakkonversi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'mbkm/prodi/tolakkonversi/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@tolakKonversi',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@tolakKonversi',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.prodi.tolakkonversi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.staff' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/staff',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@staffIndex',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@staffIndex',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.staff',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.staff.riwayat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/staff/riwayat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@staffRiwayat',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@staffRiwayat',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.staff.riwayat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.staff.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mbkm/staff/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@approveStaff',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\ApprovalController@approveStaff',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.staff.approve',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'staff.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/staff-print',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@print',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@print',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'staff.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/{mbkm}/donwload-konversi-pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@downloadPdf',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@downloadPdf',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.pdf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.logbook' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/{mbkmId}/logbook',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\LogbookController@index',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\LogbookController@index',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.logbook',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mbkm/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@detail',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@detail',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.detail',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mbkm.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'mbkm/{mbkm}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@destroy',
        'controller' => 'App\\Http\\Controllers\\Mbkm\\MbkmController@destroy',
        'namespace' => NULL,
        'prefix' => '/mbkm',
        'where' => 
        array (
        ),
        'as' => 'mbkm.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mbkm' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program-mbkm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'program-mbkm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramMbkmController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramMbkmController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'program-mbkm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program-mbkm.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'program-mbkm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramMbkmController@store',
        'controller' => 'App\\Http\\Controllers\\ProgramMbkmController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'program-mbkm.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program-mbkm.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'program-mbkm/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramMbkmController@delete',
        'controller' => 'App\\Http\\Controllers\\ProgramMbkmController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'program-mbkm.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'matkul' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'matkul',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MataKuliahController@index',
        'controller' => 'App\\Http\\Controllers\\MataKuliahController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'matkul',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'matkul.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'matkul/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MataKuliahController@create',
        'controller' => 'App\\Http\\Controllers\\MataKuliahController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'matkul.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'matkul.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'matkul',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MataKuliahController@store',
        'controller' => 'App\\Http\\Controllers\\MataKuliahController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'matkul.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'matkul.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'matkul/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MataKuliahController@edit',
        'controller' => 'App\\Http\\Controllers\\MataKuliahController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'matkul.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'matkul.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'matkul/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MataKuliahController@update',
        'controller' => 'App\\Http\\Controllers\\MataKuliahController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'matkul.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'matkul.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'matkul/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web,mahasiswa',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MataKuliahController@destroy',
        'controller' => 'App\\Http\\Controllers\\MataKuliahController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'matkul.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yqKTtMGl109VJfaN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detailkp',
        'controller' => 'App\\Http\\Controllers\\QRController@detailkp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yqKTtMGl109VJfaN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H8ZStgAdtDLcIv9M' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-sempro/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detailsempro',
        'controller' => 'App\\Http\\Controllers\\QRController@detailsempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::H8ZStgAdtDLcIv9M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RgQRMloG4raWar6z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detailskripsi',
        'controller' => 'App\\Http\\Controllers\\QRController@detailskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RgQRMloG4raWar6z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qUDXxBR8GC7Cj1PX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-skripsi-final/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detailskripsifinal',
        'controller' => 'App\\Http\\Controllers\\QRController@detailskripsifinal',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qUDXxBR8GC7Cj1PX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sbtJzzqAw2BrRXYo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-undangan-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detail_undangan_kp',
        'controller' => 'App\\Http\\Controllers\\QRController@detail_undangan_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::sbtJzzqAw2BrRXYo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xHmyoBJ9iQduTjej' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-undangan-sempro/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detail_undangan_sempro',
        'controller' => 'App\\Http\\Controllers\\QRController@detail_undangan_sempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xHmyoBJ9iQduTjej',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iBtsSlKCj0yVzZtx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-undangan-sidang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detail_undangan_sidang',
        'controller' => 'App\\Http\\Controllers\\QRController@detail_undangan_sidang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::iBtsSlKCj0yVzZtx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GUEJApLiwfxKZo2h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-surat-permohonan-pengajuan-topik-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detailsuratpermohonanpengajuantopikskripsi',
        'controller' => 'App\\Http\\Controllers\\QRController@detailsuratpermohonanpengajuantopikskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GUEJApLiwfxKZo2h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yEtiqAuJusrTITcO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-form-pengajuan-topik-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detailformpengajuantopikskripsi',
        'controller' => 'App\\Http\\Controllers\\QRController@detailformpengajuantopikskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yEtiqAuJusrTITcO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g7wOco6NSMNWwoS2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-surat-permohonan-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detail_surat_permohonan_kp',
        'controller' => 'App\\Http\\Controllers\\QRController@detail_surat_permohonan_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::g7wOco6NSMNWwoS2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CE7NAwvfY3bFtxcT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail-form-permohonan-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\QRController@detail_form_permohonan_kp',
        'controller' => 'App\\Http\\Controllers\\QRController@detail_form_permohonan_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CE7NAwvfY3bFtxcT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BbOoiDA660dDdGom' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'developer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@index',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BbOoiDA660dDdGom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9NdjlTPxv8q8N2UP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'developer/fahril-hadi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@fahril',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@fahril',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::9NdjlTPxv8q8N2UP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VJMTRTFsgyfNMyxx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'developer/m-seprinaldi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@naldi',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@naldi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::VJMTRTFsgyfNMyxx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::r03cNvB9CM7Ocz1l' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'developer/rahul-ilsa-tajri-mukhti',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@rahul',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@rahul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::r03cNvB9CM7Ocz1l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RBsto8yoZCTaNZ18' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'developer/ahmad-fajri',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@ahmad',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@ahmad',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RBsto8yoZCTaNZ18',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JpvX1Ka6Ay4916Jm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'developer/yabes-maychel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@yabes',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@yabes',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JpvX1Ka6Ay4916Jm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YtdcRmHPFYHBxzSE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'developer/yasmine',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@yasmine',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@yasmine',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YtdcRmHPFYHBxzSE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FarFvfZ1FpS8aTFv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'guest:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\LoginController@index',
        'controller' => 'App\\Http\\Controllers\\LoginController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FarFvfZ1FpS8aTFv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'guest:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\LoginController@postlogin',
        'controller' => 'App\\Http\\Controllers\\LoginController@postlogin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Dm0Qlw8otHZLSZOQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:dosen,web,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\LoginController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Dm0Qlw8otHZLSZOQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::47OFaiFqp3Stn35v' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usulankp/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@indexusulankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@indexusulankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::47OFaiFqp3Stn35v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JAJsHRiWAsNdMiCU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usulankp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@createusulankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@createusulankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JAJsHRiWAsNdMiCU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Fg8Z4mZl5HR3OFaB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'usulankp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@storeusulankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@storeusulankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Fg8Z4mZl5HR3OFaB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8Oe72jsTXQmHcnZp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usulankp-ulang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@createusulankp_ulang',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@createusulankp_ulang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8Oe72jsTXQmHcnZp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xy2TWC441nImZmuA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'usulankp-ulang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@storeusulankp_ulang',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@storeusulankp_ulang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xy2TWC441nImZmuA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MV8btF9W1mHwh2g0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usuljudul/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@indexusuljudul',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@indexusuljudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MV8btF9W1mHwh2g0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qia2ZvjbC81hwwGv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usuljudul/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createusuljudul',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createusuljudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qia2ZvjbC81hwwGv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lWApoGqr9UE4WVTA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'usuljudul/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storeusuljudul',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storeusuljudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lWApoGqr9UE4WVTA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JWWO5WR148R3QQuF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usuljudul-ulang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@create_ulang_usuljudul',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@create_ulang_usuljudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JWWO5WR148R3QQuF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rN7FYbt5Bct5keyh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'usuljudul-ulang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@store_ulang_usuljudul',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@store_ulang_usuljudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rN7FYbt5Bct5keyh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zipificsTxnf6jkC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'permohonankp/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@indexpermohonan',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@indexpermohonan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zipificsTxnf6jkC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uyfJwcNp5qc3hQxK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'permohonankp/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@createpermohonan',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@createpermohonan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uyfJwcNp5qc3hQxK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::llLo0bUmaOMQMltU' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'permohonankp/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@storepermohonan',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@storepermohonan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::llLo0bUmaOMQMltU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::K9sJcekwshTn4Ugp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'balasankp/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@indexbalasan',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@indexbalasan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::K9sJcekwshTn4Ugp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XaQIbrKrRxxpmHfx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'balasankp/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@createbalasan',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@createbalasan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XaQIbrKrRxxpmHfx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::V07jKgxg5TcVwWWk' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'balasankp/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@storebalasan',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@storebalasan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::V07jKgxg5TcVwWWk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e9IO4cQlsJG28JhK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'seminarkp/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@indexsemkp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@indexsemkp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::e9IO4cQlsJG28JhK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IooiawCcuqf4gAqh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-semkp/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@createsemkp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@createsemkp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IooiawCcuqf4gAqh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uXTG6sfXjZUOffTI' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftar-semkp/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@storesemkp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@storesemkp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uXTG6sfXjZUOffTI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jelP9Pif8ngpJDIw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kpti10-kp/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@indexkpti_10',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@indexkpti_10',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jelP9Pif8ngpJDIw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N0gaBLd3bXMyg6Qb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kpti10-kp/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@createkpti_10',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@createkpti_10',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::N0gaBLd3bXMyg6Qb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ik2S5mmqBTyBku8j' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kpti10-kp/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@storekpti_10',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@storekpti_10',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ik2S5mmqBTyBku8j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wPdbuPLYCsamKNZq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-sempro/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@indexsempro',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@indexsempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wPdbuPLYCsamKNZq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kfhoPbxIfCFJQjTa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-sempro/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createsempro',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createsempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kfhoPbxIfCFJQjTa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4wdQiIyTEfjtCCR7' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftar-sempro/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storesempro',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storesempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4wdQiIyTEfjtCCR7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::31XGAqYw7yE6hVMQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-sidang/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@indexsidang',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@indexsidang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::31XGAqYw7yE6hVMQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PQ9Foq6NnxZrtnD2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-sidang/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createsidang',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createsidang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PQ9Foq6NnxZrtnD2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::taYlupS6jrJ0OHYX' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftar-sidang/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storesidang',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storesidang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::taYlupS6jrJ0OHYX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YAf6TFH82P9TKXZz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perpanjangan-revisi/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createperpanjangan_revisi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createperpanjangan_revisi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YAf6TFH82P9TKXZz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MYLbjrX48R3573FU' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan-revisi/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storeperpanjangan_revisi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storeperpanjangan_revisi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MYLbjrX48R3573FU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0Y89AcP1oDjcWEc3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perpanjangan1-skripsi/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createperpanjangan1_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createperpanjangan1_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0Y89AcP1oDjcWEc3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iRTdxVkTcCLljJSp' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan1-skripsi/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storeperpanjangan1_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storeperpanjangan1_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::iRTdxVkTcCLljJSp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uOnFYqACRy15Mxe4' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan2-skripsi/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storeperpanjangan2_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storeperpanjangan2_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uOnFYqACRy15Mxe4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tAhbOoy7c7iZR0Zy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penyerahan-buku-skripsi/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createbukti_buku_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@createbukti_buku_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::tAhbOoy7c7iZR0Zy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a1hcBrHOM55JulnY' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penyerahan-buku-skripsi/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storebukti_buku_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@storebukti_buku_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::a1hcBrHOM55JulnY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GrXptYTIwfBbq4xf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profil-mhs/editpasswordmhs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\MahasiswaProfilController@editpswmhs',
        'controller' => 'App\\Http\\Controllers\\MahasiswaProfilController@editpswmhs',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GrXptYTIwfBbq4xf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uuqXBuo60MSTcoRr' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'profil-mhs/editpasswordmhs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\MahasiswaProfilController@updatepswmhs',
        'controller' => 'App\\Http\\Controllers\\MahasiswaProfilController@updatepswmhs',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uuqXBuo60MSTcoRr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SXsGtNssj6Pettow' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'jadwal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@jadwal_mahasiswa',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@jadwal_mahasiswa',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SXsGtNssj6Pettow',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1c3p4CHuT4RelgPm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'jadwal/mahasiswa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@seminar_mahasiswa',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@seminar_mahasiswa',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1c3p4CHuT4RelgPm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gj5xE4BIzG017CNz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'seminar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@riwayat_mahasiswa',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@riwayat_mahasiswa',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gj5xE4BIzG017CNz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HxrcyZSsqYv8XPu5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-kp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@daftarkp_mahasiswa',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@daftarkp_mahasiswa',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HxrcyZSsqYv8XPu5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DpSPdIXMwFfrSP4X' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-kp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@createusulankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@createusulankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DpSPdIXMwFfrSP4X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YAcqF3BwcW8LUQgV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'daftar-kp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@store',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YAcqF3BwcW8LUQgV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p4EdSPngRcuguvkW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'status-kp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@create',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::p4EdSPngRcuguvkW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WffPEr0AscPZBHdO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'status-kp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@store',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WffPEr0AscPZBHdO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'peminjaman' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/peminjamanmhs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanMahasiswaController@index',
        'controller' => 'App\\Http\\Controllers\\PeminjamanMahasiswaController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'peminjaman',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'riwayatmhs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/riwayatmhs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\RiwayatController@riwayatmhs',
        'controller' => 'App\\Http\\Controllers\\RiwayatController@riwayatmhs',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'riwayatmhs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4kgI3UhT4zSzDYXM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanMahasiswaController@destroy',
        'controller' => 'App\\Http\\Controllers\\PeminjamanMahasiswaController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4kgI3UhT4zSzDYXM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zURyy3fi0GmDTNau' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanMahasiswaController@edit',
        'controller' => 'App\\Http\\Controllers\\PeminjamanMahasiswaController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zURyy3fi0GmDTNau',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zqOr0w8zeIG4zaL1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'inventaris/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanMahasiswaController@update',
        'controller' => 'App\\Http\\Controllers\\PeminjamanMahasiswaController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zqOr0w8zeIG4zaL1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'formusulan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/formpinjam',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\UsulanController@index',
        'controller' => 'App\\Http\\Controllers\\UsulanController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'formusulan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iF8mxU4CfpdU913w' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'inventaris/usulan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\UsulanController@create',
        'controller' => 'App\\Http\\Controllers\\UsulanController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::iF8mxU4CfpdU913w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ot87QexPRbyelhaz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/perpanjangan-revisi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_perpanjangan_revisi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_perpanjangan_revisi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ot87QexPRbyelhaz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X5JsUX8Aiv1IxEAv' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulankp/admin/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulankp_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulankp_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::X5JsUX8Aiv1IxEAv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mR9LOxyQFf9yappU' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulankp/admin/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulankp_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulankp_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mR9LOxyQFf9yappU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ojr18AeXbGZOiZeQ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'semkp/admin/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approvesemkp_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approvesemkp_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ojr18AeXbGZOiZeQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uuq8f0tkNdwF81xK' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'semkp/admin/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolaksemkp_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolaksemkp_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uuq8f0tkNdwF81xK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gkcky5CCtbEOms7x' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kerja-praktek/admin/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_kp_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_kp_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gkcky5CCtbEOms7x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zI9Kc2lKaVKwQgbe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sempro/admin/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_sempro_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_sempro_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zI9Kc2lKaVKwQgbe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rW6yD5SCS0wRPC0O' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sidang/admin/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_sidang_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_sidang_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rW6yD5SCS0wRPC0O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4PjcE5RvZLCWFKIw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan/admin/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@persetujuan_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@persetujuan_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4PjcE5RvZLCWFKIw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hpHLm4f1sXohcIeQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan/admin/detail/usulankp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hpHLm4f1sXohcIeQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gLdgL6TJMOX8fmYu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan/admin/detail/kpti10/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_kpti10_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_kpti10_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gLdgL6TJMOX8fmYu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pMOuAt2SxPgYQDI0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan/admin/detail/usulanjudul/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_usulanjudul_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_usulanjudul_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pMOuAt2SxPgYQDI0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sDnSCTKJJQgYRjI7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan/admin/detail/sempro/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_sempro_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_sempro_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::sDnSCTKJJQgYRjI7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Blf5AtLeYZUJ1bfM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan/admin/detail/sidang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_sidang_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_persetujuan_sidang_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Blf5AtLeYZUJ1bfM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4pFuztB9HCJI9jge' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sidang/admin/perpanjangan-1/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_perpanjangan_1_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_perpanjangan_1_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4pFuztB9HCJI9jge',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WFiKrVYlGqLPGEcs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sidang/admin/perpanjangan-2/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_perpanjangan_2_admin',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_perpanjangan_2_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WFiKrVYlGqLPGEcs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5p5aAAyhJGmXfBkG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profil-staff/editpasswordstaff',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\StaffProfilController@editpswstaff',
        'controller' => 'App\\Http\\Controllers\\StaffProfilController@editpswstaff',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5p5aAAyhJGmXfBkG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SsHYMHRafHWlCvrC' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'profil-staff/editpasswordstaff',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\StaffProfilController@updatepswstaff',
        'controller' => 'App\\Http\\Controllers\\StaffProfilController@updatepswstaff',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SsHYMHRafHWlCvrC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HjMCC8GEjTq83O0L' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dosen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenController@index',
        'controller' => 'App\\Http\\Controllers\\DosenController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HjMCC8GEjTq83O0L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uOhEU9DAK5ZgWOA9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dosen/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenController@create',
        'controller' => 'App\\Http\\Controllers\\DosenController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uOhEU9DAK5ZgWOA9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kdZ9AWAIGBEgOqh3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dosen/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenController@store',
        'controller' => 'App\\Http\\Controllers\\DosenController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kdZ9AWAIGBEgOqh3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6ME43ts2dSEJfTrB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dosen/edit/{dosen}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenController@edit',
        'controller' => 'App\\Http\\Controllers\\DosenController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6ME43ts2dSEJfTrB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'dosen' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d1hMOQ4xM1ouCG44' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'dosen/edit/{dosen}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenController@update',
        'controller' => 'App\\Http\\Controllers\\DosenController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::d1hMOQ4xM1ouCG44',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'dosen' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KmLUUqojnRgbGbAJ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dosen/{dosen}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenController@destroy',
        'controller' => 'App\\Http\\Controllers\\DosenController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::KmLUUqojnRgbGbAJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'dosen' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dxmdkDJEF7Ivvv5y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mahasiswa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MahasiswaController@index',
        'controller' => 'App\\Http\\Controllers\\MahasiswaController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::dxmdkDJEF7Ivvv5y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ibPCEacXWPEF37iD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mahasiswa/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MahasiswaController@create',
        'controller' => 'App\\Http\\Controllers\\MahasiswaController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ibPCEacXWPEF37iD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Cah0iuar4VLTXaLO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'mahasiswa/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MahasiswaController@store',
        'controller' => 'App\\Http\\Controllers\\MahasiswaController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Cah0iuar4VLTXaLO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CGPThOrnxtS6Jiwm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mahasiswa/edit/{mahasiswa}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MahasiswaController@edit',
        'controller' => 'App\\Http\\Controllers\\MahasiswaController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CGPThOrnxtS6Jiwm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mahasiswa' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Suwayubo794iOQtZ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'mahasiswa/edit/{mahasiswa}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MahasiswaController@update',
        'controller' => 'App\\Http\\Controllers\\MahasiswaController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Suwayubo794iOQtZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mahasiswa' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::j8KJVlmiDp6wtfG8' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'mahasiswa/{mahasiswa}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MahasiswaController@destroy',
        'controller' => 'App\\Http\\Controllers\\MahasiswaController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::j8KJVlmiDp6wtfG8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'mahasiswa' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IgbBjJsb8XOQvPc8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@index',
        'controller' => 'App\\Http\\Controllers\\RoleController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IgbBjJsb8XOQvPc8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T9nqH1bIQb71LCFv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'role/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@create',
        'controller' => 'App\\Http\\Controllers\\RoleController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::T9nqH1bIQb71LCFv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CxWKitsBxItZyhq9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'role/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@store',
        'controller' => 'App\\Http\\Controllers\\RoleController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CxWKitsBxItZyhq9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tCPjHAxVLLEUZdeD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'role/edit/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@edit',
        'controller' => 'App\\Http\\Controllers\\RoleController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::tCPjHAxVLLEUZdeD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'role' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lhI53aBQ5JeKBjUh' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'role/edit/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@update',
        'controller' => 'App\\Http\\Controllers\\RoleController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lhI53aBQ5JeKBjUh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'role' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zfChNjHCxfImhsnE' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'role/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@destroy',
        'controller' => 'App\\Http\\Controllers\\RoleController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zfChNjHCxfImhsnE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'role' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DTAdgMUAZi1jNG5G' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'prodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\ProdiController@index',
        'controller' => 'App\\Http\\Controllers\\ProdiController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DTAdgMUAZi1jNG5G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xSdnAhQNUAZ7Sn4D' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'prodi/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\ProdiController@create',
        'controller' => 'App\\Http\\Controllers\\ProdiController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xSdnAhQNUAZ7Sn4D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5K3gS1fEpIPVwZZ8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'prodi/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\ProdiController@store',
        'controller' => 'App\\Http\\Controllers\\ProdiController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5K3gS1fEpIPVwZZ8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::K1FYuCBNmGAMqiwh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'prodi/edit/{prodi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\ProdiController@edit',
        'controller' => 'App\\Http\\Controllers\\ProdiController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::K1FYuCBNmGAMqiwh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'prodi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'prodi.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\ProdiController@update',
        'controller' => 'App\\Http\\Controllers\\ProdiController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'prodi.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::O5yQSlxuV9C9q5l6' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'prodi/{prodi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\ProdiController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProdiController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::O5yQSlxuV9C9q5l6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'prodi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a9rJSf21II8B8NIn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konsentrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\KonsentrasiController@index',
        'controller' => 'App\\Http\\Controllers\\KonsentrasiController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::a9rJSf21II8B8NIn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::K1xCbWyaY8tLXaAc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konsentrasi/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\KonsentrasiController@create',
        'controller' => 'App\\Http\\Controllers\\KonsentrasiController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::K1xCbWyaY8tLXaAc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yX7YbgDdHMd4DDAj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'konsentrasi/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\KonsentrasiController@store',
        'controller' => 'App\\Http\\Controllers\\KonsentrasiController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yX7YbgDdHMd4DDAj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PUDfRtwjBDZGh9KE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'konsentrasi/edit/{konsentrasi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\KonsentrasiController@edit',
        'controller' => 'App\\Http\\Controllers\\KonsentrasiController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PUDfRtwjBDZGh9KE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'konsentrasi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t9y9YiAUWTr0Ci1F' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'konsentrasi/edit/{konsentrasi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\KonsentrasiController@update',
        'controller' => 'App\\Http\\Controllers\\KonsentrasiController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::t9y9YiAUWTr0Ci1F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'konsentrasi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6LhUNl79wEiZThTH' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'konsentrasi/{konsentrasi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\KonsentrasiController@destroy',
        'controller' => 'App\\Http\\Controllers\\KonsentrasiController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6LhUNl79wEiZThTH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'konsentrasi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EykWiB056HHs7jqC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EykWiB056HHs7jqC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pkVOopk5xJi47hAE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\UserController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pkVOopk5xJi47hAE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::V7RtLyIgWdBRj7N0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::V7RtLyIgWdBRj7N0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M6SAMKuA1TyFxnIs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/edit/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\UserController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::M6SAMKuA1TyFxnIs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'user' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BkZ7RVSGGINOeHmd' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'user/edit/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BkZ7RVSGGINOeHmd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'user' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pUhHna035I2dCVcY' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'user/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pUhHna035I2dCVcY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'user' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ap2pbkH4DXZWoUmR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'plp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@plp_index',
        'controller' => 'App\\Http\\Controllers\\UserController@plp_index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ap2pbkH4DXZWoUmR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BOjr3P7M72LK6y2E' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'plp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@plp_create',
        'controller' => 'App\\Http\\Controllers\\UserController@plp_create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BOjr3P7M72LK6y2E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m6rAFAFR0xcN6OZQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'plp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@plp_store',
        'controller' => 'App\\Http\\Controllers\\UserController@plp_store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::m6rAFAFR0xcN6OZQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0gr2ZI9hEfPtz6XK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'plp/edit/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@plp_edit',
        'controller' => 'App\\Http\\Controllers\\UserController@plp_edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0gr2ZI9hEfPtz6XK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'user' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FYno8mc3HgHFjKOs' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'plp/edit/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@plp_update',
        'controller' => 'App\\Http\\Controllers\\UserController@plp_update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FYno8mc3HgHFjKOs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'user' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MBovJB2TDCYcwEvC' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'reset-password/mahasiswa/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\MahasiswaController@reset_password',
        'controller' => 'App\\Http\\Controllers\\MahasiswaController@reset_password',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MBovJB2TDCYcwEvC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eX4WAfJ0ojEeTLug' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'reset-password/dosen/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenController@reset_password',
        'controller' => 'App\\Http\\Controllers\\DosenController@reset_password',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::eX4WAfJ0ojEeTLug',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bBx6PuwkVjN5iqCF' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'reset-password/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@reset_password',
        'controller' => 'App\\Http\\Controllers\\UserController@reset_password',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::bBx6PuwkVjN5iqCF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vv58rxtwWhUO7Q3o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pendaftaran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_kp_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_kp_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::vv58rxtwWhUO7Q3o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ewF8toVVUskGnmyp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kerja-praktek',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_kp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ewF8toVVUskGnmyp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rzkAaPsqDp2qgTip' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/pembimbing-penguji/riwayat-seminar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@riwayat_seminar_pembimbing_penguji',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@riwayat_seminar_pembimbing_penguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rzkAaPsqDp2qgTip',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z3VaWI11Dzf8c6Sq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pembimbing-penguji/riwayat-bimbingan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@riwayat_bimbingan_pembimbing_penguji',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@riwayat_bimbingan_pembimbing_penguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::z3VaWI11Dzf8c6Sq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xVQ5GvoYNgT4Pi5Y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xVQ5GvoYNgT4Pi5Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7TqUOqAZiIoKTr7Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan-kp-skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@persetujuankpskripsi_dosen',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@persetujuankpskripsi_dosen',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7TqUOqAZiIoKTr7Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NXNzj80PBq5ktsqH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan-skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@persetujuanskripsi_dosen',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@persetujuanskripsi_dosen',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::NXNzj80PBq5ktsqH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lhdkSyZ6ZReZezd9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/suratperusahaan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpersetujuan_balasankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpersetujuan_balasankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lhdkSyZ6ZReZezd9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mEchUf3Nt2LalrK8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/kpti10/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpersetujuan_kpti10',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpersetujuan_kpti10',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mEchUf3Nt2LalrK8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LH4i8xTJi6flFDLi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pembimbing/kerja-praktek',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_kp_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_kp_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LH4i8xTJi6flFDLi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CJudups35SgA7KSB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/usulanjudul/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_usulanjudul',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_usulanjudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CJudups35SgA7KSB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Lx3MrE37oAiQoyuX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/sempro/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_daftarsempro',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_daftarsempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Lx3MrE37oAiQoyuX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3NUJx2tCmGEYkqvq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/sidang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_daftarsidang',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_daftarsidang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3NUJx2tCmGEYkqvq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3cHWOSgu6RYTv70G' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/perpanjangan-1/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_perpanjangan_1',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_perpanjangan_1',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3cHWOSgu6RYTv70G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CYS7EwMbw2UQNpch' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/perpanjangan-2/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_perpanjangan_2',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_perpanjangan_2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CYS7EwMbw2UQNpch',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fAiOmVC5G8ncgvXN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/bukti-buku-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_bukti_buku_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailpersetujuan_bukti_buku_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fAiOmVC5G8ncgvXN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BnOXCwywghAGcG4i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/pembimbing/perpanjangan-1/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_perpanjangan_1_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_perpanjangan_1_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BnOXCwywghAGcG4i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lfJ2iN2b3QDFX9U1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/pembimbing/perpanjangan-2/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_perpanjangan_2_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_perpanjangan_2_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lfJ2iN2b3QDFX9U1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z3midKa3EPVoEaIV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/pembimbing/perpanjangan-revisi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_perpanjangan_revisi_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_perpanjangan_revisi_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Z3midKa3EPVoEaIV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fXuRHxuI80UgKjDH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/pembimbing/bukti-buku-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_bukti_buku_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_bukti_buku_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fXuRHxuI80UgKjDH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LtlEk4L2UeLTEF2J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/riwayat/pembimbing/bukti-buku-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_riwayat_pemb_bukti_buku_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_riwayat_pemb_bukti_buku_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LtlEk4L2UeLTEF2J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Vn9fULNUyvGAK1A8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pembimbing/skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_skripsi_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@pendaftaran_skripsi_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Vn9fULNUyvGAK1A8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZiI6wWiYAJpUkb4q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'permohonan-kp/detail/pembimbing/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detailpermohonankp_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detailpermohonankp_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ZiI6wWiYAJpUkb4q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nqlsKzUZAlGLqOdP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-semkp/detail/pembimbing/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detailusulan_semkp_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detailusulan_semkp_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::nqlsKzUZAlGLqOdP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jEUoxgx9UvINRuIO' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulan-semkp/pembimbing/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulan_semkp_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulan_semkp_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jEUoxgx9UvINRuIO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::swndNnow9sV1pMg7' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulan-semkp/pembimbing/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulan_semkp_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulan_semkp_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::swndNnow9sV1pMg7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pmf6L7HwiCk0giTh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usuljudul/detail/pembimbing2/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detailusuljudul_pembimbing2',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detailusuljudul_pembimbing2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pmf6L7HwiCk0giTh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kNnW1HtgcDQCFTfE' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulankp/pembimbing/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulankp_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulankp_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kNnW1HtgcDQCFTfE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5HGdXbVE8gg1smDO' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulankp/pembimbing/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulankp_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulankp_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5HGdXbVE8gg1smDO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1quKOQhaiPMu4N7F' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'permohonankp/pembimbing/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approvepermohonankp_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approvepermohonankp_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1quKOQhaiPMu4N7F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hGQcn3DFGfywJ4JS' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'permohonankp-koordinator/pembimbing/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakpermohonankp_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakpermohonankp_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hGQcn3DFGfywJ4JS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QvtamA30UWsdITZP' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usuljudul/pembimbing1/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveusuljudul_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveusuljudul_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QvtamA30UWsdITZP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xrHfQBzSZ2w846eo' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usuljudul/pembimbing1/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakusuljudul_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakusuljudul_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xrHfQBzSZ2w846eo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CTZuEHmBPOzo3rNh' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsempro/pembimbing1/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsempro_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsempro_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CTZuEHmBPOzo3rNh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7ZyDu5fGCqBXqGJ3' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsempro/pembimbing1/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsempro_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsempro_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7ZyDu5fGCqBXqGJ3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ODswrlC8Yk1OsKKX' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsidang/pembimbing1/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsidang_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsidang_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ODswrlC8Yk1OsKKX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ora5fQ6rHkCHr01t' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsidang/pembimbing1/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsidang_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsidang_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ora5fQ6rHkCHr01t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6TnU3sx5JD1AACRS' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsempro/pembimbing2/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsempro_pembimbing2',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsempro_pembimbing2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6TnU3sx5JD1AACRS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GeedpaI37KpTJASt' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsempro/pembimbing2/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsempro_pembimbing2',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsempro_pembimbing2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GeedpaI37KpTJASt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C401GylC6m8zdsyw' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsidang/pembimbing2/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsidang_pembimbing2',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsidang_pembimbing2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::C401GylC6m8zdsyw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eynFKqiJXpqyEQO6' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsidang/pembimbing2/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsidang_pembimbing2',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsidang_pembimbing2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::eynFKqiJXpqyEQO6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IKlXcdAxcLQUFg0F' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usuljudul/pembimbing2/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveusuljudul_pembimbing2',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveusuljudul_pembimbing2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IKlXcdAxcLQUFg0F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D8sYP610HEifmBDf' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usuljudul/pembimbing2/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakusuljudul_pembimbing2',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakusuljudul_pembimbing2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::D8sYP610HEifmBDf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mVItVN6tq4IEE63H' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'selesaiseminar-kp/pembimbing/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approveselesaiseminarkp_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approveselesaiseminarkp_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mVItVN6tq4IEE63H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VHDvrcBXlBoF1sX1' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'selesaiseminar-kp/pembimbing/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakselesaiseminarkp_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakselesaiseminarkp_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::VHDvrcBXlBoF1sX1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HiqfJDobZuGmITPb' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'selesaisempro/pembimbing/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveselesaisempro_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveselesaisempro_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HiqfJDobZuGmITPb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nyGZDiIDZ4YJijx9' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'selesaisempro/pembimbing/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakselesaisempro_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakselesaisempro_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::nyGZDiIDZ4YJijx9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ETaD3HMZrSLwlEGY' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'lewat-batas-sidang/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@lewat_batas_sidang',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@lewat_batas_sidang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ETaD3HMZrSLwlEGY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Rug6goBBm0RXrt7Y' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'lewat-batas-revisi-spesial/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@lewat_batas_revisi_spesial',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@lewat_batas_revisi_spesial',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Rug6goBBm0RXrt7Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bnjfNPy8DDrbdJax' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'lewat-batas-penyerahan-skripsi/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@lewat_batas_penyerahan_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@lewat_batas_penyerahan_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::bnjfNPy8DDrbdJax',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::88Gx8QyAppmbtzec' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'selesaisidang/pembimbing/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveselesaisidang_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveselesaisidang_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::88Gx8QyAppmbtzec',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zyCC4iiH44QIoOKA' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'selesaisidang/pembimbing/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakselesaisidang_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakselesaisidang_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zyCC4iiH44QIoOKA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0hzPmM39uo0jbWNm' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan1/pembimbing/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan1_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan1_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0hzPmM39uo0jbWNm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::S3vtXDdifAt7lcrJ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan1/pembimbing/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan1_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan1_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::S3vtXDdifAt7lcrJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RUgjSKOm0dMiMlZ8' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan2/pembimbing/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan2_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan2_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RUgjSKOm0dMiMlZ8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PfueS5oWD4gtiu5b' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan2/pembimbing/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan2_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan2_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PfueS5oWD4gtiu5b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::doqASyc3koOjqPBA' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan-revisi/pembimbing/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan_revisi_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan_revisi_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::doqASyc3koOjqPBA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jafmQxRcCpeftfDz' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan-revisi/pembimbing/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan_revisi_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan_revisi_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jafmQxRcCpeftfDz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PdHOOGXf67RlBgO5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pendaftaran/kp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@daftarkp_dosen',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@daftarkp_dosen',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PdHOOGXf67RlBgO5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A1FOTh1pMZPORWWe' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'pendaftaran-kp/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approve',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approve',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::A1FOTh1pMZPORWWe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BhoASjP66tRQ8MpI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayatkp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@riwayat',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BhoASjP66tRQ8MpI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ivsfgn62fstZmS72' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profil-dosen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenProfilController@index',
        'controller' => 'App\\Http\\Controllers\\DosenProfilController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ivsfgn62fstZmS72',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b2px3neHsvFkmB82' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profil-dosen/editfotodsn/{dosen}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenProfilController@editfotodsn',
        'controller' => 'App\\Http\\Controllers\\DosenProfilController@editfotodsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::b2px3neHsvFkmB82',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'dosen' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lD6vBCfCge3jhJIi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'profil-dosen/editfotodsn/{dosen}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenProfilController@updatefotodsn',
        'controller' => 'App\\Http\\Controllers\\DosenProfilController@updatefotodsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lD6vBCfCge3jhJIi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'dosen' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fMyjavhDfr7YSkFH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profil-dosen/editpassworddsn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenProfilController@editpswdsn',
        'controller' => 'App\\Http\\Controllers\\DosenProfilController@editpswdsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fMyjavhDfr7YSkFH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HdjgfO6rclprnnVe' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'profil-dosen/editpassworddsn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\DosenProfilController@updatepswdsn',
        'controller' => 'App\\Http\\Controllers\\DosenProfilController@updatepswdsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HdjgfO6rclprnnVe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9vanXxjzJscyPjZ3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'prodi/kp-skripsi/seminar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianController@index',
        'controller' => 'App\\Http\\Controllers\\PenilaianController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::9vanXxjzJscyPjZ3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DMu1lRqOTQch67wc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/seminar-pembimbing-penguji',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianController@indexpembimbing',
        'controller' => 'App\\Http\\Controllers\\PenilaianController@indexpembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DMu1lRqOTQch67wc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EPkgteyjUYlDE5hI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/riwayat-penilaian-seminar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianController@riwayat',
        'controller' => 'App\\Http\\Controllers\\PenilaianController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EPkgteyjUYlDE5hI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3IzWP3FqvoR6eexw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/riwayat-penilaian-skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianController@riwayatskripsi',
        'controller' => 'App\\Http\\Controllers\\PenilaianController@riwayatskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3IzWP3FqvoR6eexw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J3XlRKp335xqFf6z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-kp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@index',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::J3XlRKp335xqFf6z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GxlCybufRaM7rqHK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-kp/create/{penjadwalan_kp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@create',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GxlCybufRaM7rqHK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_kp' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nFduxF7FxWlmTqTQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'penilaian-kp-pembimbing/create/{penjadwalan_kp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@store_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@store_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::nFduxF7FxWlmTqTQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_kp' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dD9s818vNkcZWh0w' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'penilaian-kp-penguji/create/{penjadwalan_kp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@store_penguji',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@store_penguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::dD9s818vNkcZWh0w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_kp' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8xu8hiT3qkvUObOw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'penilaian-kp-penguji-pembimbing-sama/create/{penjadwalan_kp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@store_pembimbing_penguji_sama',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@store_pembimbing_penguji_sama',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8xu8hiT3qkvUObOw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_kp' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i1K9t10laI9z7BCx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-kp/edit/{penjadwalan_kp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@edit',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::i1K9t10laI9z7BCx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_kp' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::okI6CBCp9xaYj25W' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-kp-penguji/edit/{penilaian_kp_penguji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@update_penguji',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@update_penguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::okI6CBCp9xaYj25W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penilaian_kp_penguji' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0bjzSZLxT6lY3i6I' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-kp-pembimbing/edit/{penilaian_kp_pembimbing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@update_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@update_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0bjzSZLxT6lY3i6I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penilaian_kp_pembimbing' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Dxb2UxqCSLDHpdVI' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-kp-pembimbing-penguji/edit/sama/{penilaian_kp_penguji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@update_pembimbing_penguji_sama',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@update_pembimbing_penguji_sama',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Dxb2UxqCSLDHpdVI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penilaian_kp_penguji' => 'penjadwalan_kp_id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cPo53PT99rlwn6r7' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-kp/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@approve',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@approve',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cPo53PT99rlwn6r7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RhFDi3yxXGxwfU46' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-kp/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@tolak',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@tolak',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RhFDi3yxXGxwfU46',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Wm9WnsiSdVn2oTyV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayat-penilaian-kp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianKPController@riwayat',
        'controller' => 'App\\Http\\Controllers\\PenilaianKPController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Wm9WnsiSdVn2oTyV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QssGXAkciQijRU8Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'nilai-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@nilaikp',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@nilaikp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QssGXAkciQijRU8Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7ReqANEZDnIiNtoP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perbaikan-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@perbaikan',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@perbaikan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7ReqANEZDnIiNtoP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1AmTsjUS4sgU9c54' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'undangan-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\UndanganSeminarController@undangan_kp',
        'controller' => 'App\\Http\\Controllers\\UndanganSeminarController@undangan_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1AmTsjUS4sgU9c54',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XcoERNnuoslulDBp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'undangan-sempro/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\UndanganSeminarController@undangan_sempro',
        'controller' => 'App\\Http\\Controllers\\UndanganSeminarController@undangan_sempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XcoERNnuoslulDBp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3UQ0zLlk7VG6AYjl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'undangan-sidang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\UndanganSeminarController@undangan_sidang',
        'controller' => 'App\\Http\\Controllers\\UndanganSeminarController@undangan_sidang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3UQ0zLlk7VG6AYjl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rKDdfhDW5vNxYvaZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-sempro',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSemproController@index',
        'controller' => 'App\\Http\\Controllers\\PenilaianSemproController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rKDdfhDW5vNxYvaZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Qqak8v2duCKRpaa9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-sempro/create/{penjadwalan_sempro}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSemproController@create',
        'controller' => 'App\\Http\\Controllers\\PenilaianSemproController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Qqak8v2duCKRpaa9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LrNDDLpsmryc2dn1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'penilaian-sempro-pembimbing/create/{penjadwalan_sempro}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSemproController@store_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PenilaianSemproController@store_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LrNDDLpsmryc2dn1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1E7eW7ta6dSPR9S3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'penilaian-sempro-penguji/create/{penjadwalan_sempro}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSemproController@store_penguji',
        'controller' => 'App\\Http\\Controllers\\PenilaianSemproController@store_penguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1E7eW7ta6dSPR9S3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Dk6FqIlXHIlSlYqg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-sempro/edit/{penjadwalan_sempro}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSemproController@edit',
        'controller' => 'App\\Http\\Controllers\\PenilaianSemproController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Dk6FqIlXHIlSlYqg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UjKKXOpBFnMDLSuc' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-sempro-pembimbing/edit/{penilaian_sempro_pembimbing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSemproController@update_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PenilaianSemproController@update_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UjKKXOpBFnMDLSuc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penilaian_sempro_pembimbing' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hxOms3bSZzeskkuf' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-sempro-penguji/edit/{penjadwalan_sempro_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSemproController@update_penguji',
        'controller' => 'App\\Http\\Controllers\\PenilaianSemproController@update_penguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hxOms3bSZzeskkuf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro_id' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1g1joKjxCIvS9lB4' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-sempro/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@approve',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@approve',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1g1joKjxCIvS9lB4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::avhYFTLUbVw0axg0' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-sempro/gagal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@gagal',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@gagal',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::avhYFTLUbVw0axg0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BV7zBz8Wr99e9uxJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayat-penilaian-sempro',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSemproController@riwayat',
        'controller' => 'App\\Http\\Controllers\\PenilaianSemproController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BV7zBz8Wr99e9uxJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cJc6ZhF7dQ1FE2s3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'nilai-sempro/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@nilaisempro',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@nilaisempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cJc6ZhF7dQ1FE2s3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hID5JDjdxUChYeYw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perbaikan-sempro/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@perbaikan',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@perbaikan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hID5JDjdxUChYeYw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s41WbHWwr167y88y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'revisi-proposal/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@revisiproposal',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@revisiproposal',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::s41WbHWwr167y88y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IzkEy16gIyiOMreC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'catatansempro/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@catatansempro',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@catatansempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IzkEy16gIyiOMreC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mLZKOxVRYo3gCIOi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSkripsiController@index',
        'controller' => 'App\\Http\\Controllers\\PenilaianSkripsiController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mLZKOxVRYo3gCIOi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ezk7leGzcd9uhOTK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-skripsi/create/{penjadwalan_skripsi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSkripsiController@create',
        'controller' => 'App\\Http\\Controllers\\PenilaianSkripsiController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ezk7leGzcd9uhOTK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_skripsi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lzTFk15KvpGyhRyi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'penilaian-skripsi-pembimbing/create/{penjadwalan_skripsi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSkripsiController@store_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PenilaianSkripsiController@store_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lzTFk15KvpGyhRyi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_skripsi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Q5EBSKypAcNeQNsv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'penilaian-skripsi-penguji/create/{penjadwalan_skripsi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSkripsiController@store_penguji',
        'controller' => 'App\\Http\\Controllers\\PenilaianSkripsiController@store_penguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Q5EBSKypAcNeQNsv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_skripsi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vH4FZSQWFHH1HIrf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-skripsi/edit/{penjadwalan_skripsi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSkripsiController@edit',
        'controller' => 'App\\Http\\Controllers\\PenilaianSkripsiController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::vH4FZSQWFHH1HIrf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_skripsi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5Kv71rr6SoLt2ieR' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-skripsi-pembimbing/edit/{penilaian_skripsi_pembimbing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSkripsiController@update_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PenilaianSkripsiController@update_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5Kv71rr6SoLt2ieR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penilaian_skripsi_pembimbing' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7lrJMbjm39VnvISf' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-skripsi-penguji/edit/{penilaian_skripsi_penguji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSkripsiController@update_penguji',
        'controller' => 'App\\Http\\Controllers\\PenilaianSkripsiController@update_penguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7lrJMbjm39VnvISf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penilaian_skripsi_penguji' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J86P61EcTyAU6y64' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-skripsi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@approve',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@approve',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::J86P61EcTyAU6y64',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::u23GYRHy22FmwdyH' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'penilaian-skripsi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@tolak',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@tolak',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::u23GYRHy22FmwdyH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AwsSojlfOFGPNFew' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayat-penilaian-skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenilaianSkripsiController@riwayat',
        'controller' => 'App\\Http\\Controllers\\PenilaianSkripsiController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::AwsSojlfOFGPNFew',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lpGa05kxVnWopWGv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'nilai-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@nilaiskripsi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@nilaiskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lpGa05kxVnWopWGv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YA2383SiQ0exXUKo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perbaikan-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@perbaikan',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@perbaikan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YA2383SiQ0exXUKo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2JEcBNTnAhr5P3Id' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'revisi-skripsi/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@revisiskripsi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@revisiskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2JEcBNTnAhr5P3Id',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FZ4u1MNox87xb01X' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'catatanskripsi/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@catatanskripsi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@catatanskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FZ4u1MNox87xb01X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lmZ5fNExZaPj0XRt' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'nilaijurnal/create/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@nilaijurnal',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@nilaijurnal',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lmZ5fNExZaPj0XRt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'peminjamandsn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/peminjaman-dosen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanDosenController@index',
        'controller' => 'App\\Http\\Controllers\\PeminjamanDosenController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'peminjamandsn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'riwayatdsn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/riwayat-dosen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\RiwayatController@riwayatdsn',
        'controller' => 'App\\Http\\Controllers\\RiwayatController@riwayatdsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'riwayatdsn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::es75ObJuBRrOkW5Y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/delete-dosen/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanDosenController@destroydsn',
        'controller' => 'App\\Http\\Controllers\\PeminjamanDosenController@destroydsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::es75ObJuBRrOkW5Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UJiDbZy6zAKqd7Qf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/edit-dosen/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanDosenController@editdsn',
        'controller' => 'App\\Http\\Controllers\\PeminjamanDosenController@editdsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UJiDbZy6zAKqd7Qf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s7773THJ9zDFXAdS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'inventaris/update-dosen/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanDosenController@updatedsn',
        'controller' => 'App\\Http\\Controllers\\PeminjamanDosenController@updatedsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::s7773THJ9zDFXAdS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'formusulandosen' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/formpinjam-dosen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\UsulanController@indexdsn',
        'controller' => 'App\\Http\\Controllers\\UsulanController@indexdsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'formusulandosen',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4IUhEN5WjgKwFXbm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'inventaris/usulan-dosen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
        ),
        'uses' => 'App\\Http\\Controllers\\UsulanController@createdsn',
        'controller' => 'App\\Http\\Controllers\\UsulanController@createdsn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4IUhEN5WjgKwFXbm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@index',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'form',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RaOnob9BOQZQRlGP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayat-penjadwalan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@riwayat',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RaOnob9BOQZQRlGP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9B3tvwccSACkrPPP' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'clear',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@clear',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@clear',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::9B3tvwccSACkrPPP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vpTwPD4qj5rnt8XQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-kp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@index',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::vpTwPD4qj5rnt8XQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gq5a0KEs9moiqRl0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-kp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@create',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gq5a0KEs9moiqRl0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cgnOS6olb6QfxyhH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'form-kp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@store',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cgnOS6olb6QfxyhH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uRrRJsfCEOhEoN8V' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'form-kp/{penjadwalan_kp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@destroy',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uRrRJsfCEOhEoN8V',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_kp' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3dNTTmJQsW3I08Ta' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayat-penjadwalan-kp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@riwayat',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3dNTTmJQsW3I08Ta',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f5Pearnv5CeBPI4i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-sempro',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@index',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::f5Pearnv5CeBPI4i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jud65JdTvavwL3X7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-sempro/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@create',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jud65JdTvavwL3X7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rUboLUO1ZSXwcgSB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'form-sempro/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@store',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rUboLUO1ZSXwcgSB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RQzw7XqPAER7Vg7z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-sempro/edit/{penjadwalan_sempro}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@edit',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RQzw7XqPAER7Vg7z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yrSJh8AA5DM1Totp' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'form-sempro/edit/{penjadwalan_sempro}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@update',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yrSJh8AA5DM1Totp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0edBhZSiU4TRLjPk' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'form-sempro/{penjadwalan_sempro}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@destroy',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0edBhZSiU4TRLjPk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aNl4mHdAv0KOPZFh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayat-penjadwalan-sempro',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@riwayat',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::aNl4mHdAv0KOPZFh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SW5hpiZLIZxj5oTv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-sempro/riwayat-judul/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@riwayatjudul',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@riwayatjudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SW5hpiZLIZxj5oTv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HX0HwEGh0Bpu0Z5f' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@index',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HX0HwEGh0Bpu0Z5f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6dHllkwf5B6EeXRU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-skripsi/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@create',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6dHllkwf5B6EeXRU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::B5ZO77tx0Soo4j9R' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'form-skripsi/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@store',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::B5ZO77tx0Soo4j9R',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eLX5fRL6mLL2mbPC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-skripsi/edit/{penjadwalan_skripsi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@edit',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::eLX5fRL6mLL2mbPC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_skripsi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1fWj4iOUzFl769VW' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'form-skripsi/edit/{penjadwalan_skripsi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@update',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1fWj4iOUzFl769VW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_skripsi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HO0IyeSxFdpppnFv' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'form-skripsi/{penjadwalan_skripsi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@destroy',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HO0IyeSxFdpppnFv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_skripsi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tTq7E4HSBfNES031' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayat-penjadwalan-skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@riwayat',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::tTq7E4HSBfNES031',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YhdGtOhb7WHEVoPc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-skripsi/riwayat-judul/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@riwayatjudul',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@riwayatjudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YhdGtOhb7WHEVoPc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'peminjamanadm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/peminjamanadm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanAdminController@index',
        'controller' => 'App\\Http\\Controllers\\PeminjamanAdminController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'peminjamanadm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EU1kwBiEXhkCwfnz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/setuju/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanAdminController@setuju',
        'controller' => 'App\\Http\\Controllers\\PeminjamanAdminController@setuju',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EU1kwBiEXhkCwfnz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X6E1dk97vOAbwBJ4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanAdminController@ditolak',
        'controller' => 'App\\Http\\Controllers\\PeminjamanAdminController@ditolak',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::X6E1dk97vOAbwBJ4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KHaA2VPCsPA0HaBm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/kembali/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanAdminController@kembali',
        'controller' => 'App\\Http\\Controllers\\PeminjamanAdminController@kembali',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::KHaA2VPCsPA0HaBm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'riwayatadm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/riwayatadm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\RiwayatController@riwayat',
        'controller' => 'App\\Http\\Controllers\\RiwayatController@riwayat',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'riwayatadm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'stok' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/stok',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@index',
        'controller' => 'App\\Http\\Controllers\\BarangController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'stok',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'stokbaru' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'inventaris/stokbaru',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@create',
        'controller' => 'App\\Http\\Controllers\\BarangController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'stokbaru',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tambahbarang' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/tambahbarang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@addbarang',
        'controller' => 'App\\Http\\Controllers\\BarangController@addbarang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'tambahbarang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'deletebarang' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'inventaris/deletebarang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@destroy',
        'controller' => 'App\\Http\\Controllers\\BarangController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'deletebarang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'editbarang' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/editbarang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@edit',
        'controller' => 'App\\Http\\Controllers\\BarangController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'editbarang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'updatebarang' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'inventaris/updatebarang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@update',
        'controller' => 'App\\Http\\Controllers\\BarangController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'updatebarang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pupl5F3XfP8UH09V' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kapasitas-bimbingan/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@kapasitas_index',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@kapasitas_index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pupl5F3XfP8UH09V',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Npkjf7AEtPkmpgA6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kapasitas-bimbingan/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@kapasitas_bimbingan_edit',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@kapasitas_bimbingan_edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Npkjf7AEtPkmpgA6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tdHy5Bi3WHoqIYyt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kapasitas-bimbingan/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@kapasitasbimbingan_store',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@kapasitasbimbingan_store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::tdHy5Bi3WHoqIYyt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RPV1TVeiLU3qoKsh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ceknilai-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@ceknilaikp',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@ceknilaikp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RPV1TVeiLU3qoKsh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::amSfaGNCuj6iOSV6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'beritaacara-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@beritaacarakp',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@beritaacarakp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::amSfaGNCuj6iOSV6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::86ItSwqjz52a39fc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perbaikan-pengujikp/{id}/{penguji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@perbaikanpengujikp',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@perbaikanpengujikp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::86ItSwqjz52a39fc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mz1ioYWew3ANNcDu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'nilai-sempro-pembimbing/{id}/{pembimbing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@nilaipembimbing',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@nilaipembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mz1ioYWew3ANNcDu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pOLJynAuIhv9Qj3w' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'nilai-sempro-penguji/{id}/{penguji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@nilaipenguji',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@nilaipenguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pOLJynAuIhv9Qj3w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ntV1Ypou0M2l4cG0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'nilai-skripsi-pembimbing/{id}/{pembimbing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@nilaipembimbing',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@nilaipembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ntV1Ypou0M2l4cG0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cuumAVOsa6mud9Gp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'nilai-skripsi-penguji/{id}/{penguji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@nilaipenguji',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@nilaipenguji',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cuumAVOsa6mud9Gp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::88cvocQhOZxlGh7i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perbaikan-pengujisempro/{id}/{penguji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@perbaikanpengujisempro',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@perbaikanpengujisempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::88cvocQhOZxlGh7i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q4rB1I1jdV0MMyEu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perbaikan-pengujiskripsi/{id}/{penguji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@perbaikanpengujiskripsi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@perbaikanpengujiskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::q4rB1I1jdV0MMyEu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6mhsQIyMPHnKkfim' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-sempro/cek-nilai/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@ceknilai',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@ceknilai',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6mhsQIyMPHnKkfim',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h7IAlTpn005symty' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-sempro/beritaacara-sempro/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@beritaacarasempro',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@beritaacarasempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::h7IAlTpn005symty',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IEHubupd7ABgIS49' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-skripsi/cek-nilai/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@ceknilai',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@ceknilai',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IEHubupd7ABgIS49',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jiqks2ID86QieXhR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-skripsi/draft-ba/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@draft',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@draft',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jiqks2ID86QieXhR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vIBXpgCZk8KfCYmk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'penilaian-skripsi/beritaacara-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@beritaacaraskripsi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@beritaacaraskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::vIBXpgCZk8KfCYmk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QvM6bK8JXwcWEFeP' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'sempro/undur/admin/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@undur_sempro_admin',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@undur_sempro_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QvM6bK8JXwcWEFeP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kuSCtPFAKo6vs8HL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'sempro/undur/admin/{alasan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@undur_sempro_admin',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@undur_sempro_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kuSCtPFAKo6vs8HL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jOzbPyhgXcHsBEhs' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'sidang/undur/admin/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@undur_sidang_admin',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@undur_sidang_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jOzbPyhgXcHsBEhs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gvH8jvAtLIYHShxD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'sidang/undur/admin/{alasan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@undur_sidang_admin',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@undur_sidang_admin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gvH8jvAtLIYHShxD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6PwpNQ68VHBXoIbf' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'sempro/undur/koordinator/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@undur_sempro_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@undur_sempro_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6PwpNQ68VHBXoIbf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dLbrN6XrDxF7lXw2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'sempro/undur/koordinator/{alasan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@undur_sempro_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@undur_sempro_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::dLbrN6XrDxF7lXw2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2LOgLDY3T0v7FpYI' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'sidang/undur/koordinator/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@undur_sidang_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@undur_sidang_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2LOgLDY3T0v7FpYI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ua2rcOtFxyUIzNPc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'sidang/undur/koordinator/{alasan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@undur_sidang_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@undur_sidang_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ua2rcOtFxyUIzNPc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JMZ18gbskbNEOedO' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'lewat-batas-kp/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@pop_up_lewat_batas_kp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@pop_up_lewat_batas_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JMZ18gbskbNEOedO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aekpSX1uFZQF1KMl' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'lewat-batas-kp/pembimbing/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@pop_up_lewat_batas_kp_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@pop_up_lewat_batas_kp_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::aekpSX1uFZQF1KMl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Xee2kXeiQgpldOv5' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'lewat-batas-skripsi/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@pop_up_lewat_batas_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@pop_up_lewat_batas_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Xee2kXeiQgpldOv5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LHAqCrI9BhjSlYda' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'berita-acara-final/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@beritaacarafinal',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@beritaacarafinal',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LHAqCrI9BhjSlYda',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7kucqnpoJjhIUDHN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'surat-permohonan-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@suratpermohonankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@suratpermohonankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7kucqnpoJjhIUDHN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qLOvzrn1CjHM8E6k' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-permohonan-kp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@formpermohonankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@formpermohonankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qLOvzrn1CjHM8E6k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::j2UJVwI79amoFeeN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'surat-permohonan-pengajuan-topik-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@suratpermohonanpengajuantopikskripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@suratpermohonanpengajuantopikskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::j2UJVwI79amoFeeN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JilY1LRERrolAs1c' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-pengajuan-topik-skripsi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@formpengajuantopikskripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@formpengajuantopikskripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JilY1LRERrolAs1c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OeWIUgHzi7bbsSaa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kpti10-kp/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detailkpti_10',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detailkpti_10',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OeWIUgHzi7bbsSaa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HlUzqLt3Lr7gFwlX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kpti10-kp/detail/riwayat/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detail_riwayat_prodi_kpti_10',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detail_riwayat_prodi_kpti_10',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HlUzqLt3Lr7gFwlX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kU1VDX6KjUM45QZ5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perpanjangan-revisi/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailperpanjangan_revisi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailperpanjangan_revisi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kU1VDX6KjUM45QZ5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h68B1iel9BB87pyF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perpanjangan-1/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailperpanjangan_1',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailperpanjangan_1',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::h68B1iel9BB87pyF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a2Z76hE6VXkYdNl5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'perpanjangan-2/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailperpanjangan_2',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailperpanjangan_2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::a2Z76hE6VXkYdNl5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y0ByEiW1BIFl3N2y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bukti-buku-skripsi/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailbukti_buku_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailbukti_buku_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Y0ByEiW1BIFl3N2y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f1AWN9WiH8EfPHNd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bukti-buku-skripsi/riwayat/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_riwayat_prodi_bukti_buku_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detail_riwayat_prodi_bukti_buku_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::f1AWN9WiH8EfPHNd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KAkUwHck3UQ1aWWb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statistik',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\StatistikController@index',
        'controller' => 'App\\Http\\Controllers\\StatistikController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::KAkUwHck3UQ1aWWb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TTzSDS6ihVjmzEDI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statistik/bimbingan-kp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\StatistikController@bimbingan_kp',
        'controller' => 'App\\Http\\Controllers\\StatistikController@bimbingan_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TTzSDS6ihVjmzEDI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zhYPS0SYXzweR8tI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statistik/bimbingan-skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\StatistikController@bimbingan_skripsi',
        'controller' => 'App\\Http\\Controllers\\StatistikController@bimbingan_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zhYPS0SYXzweR8tI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a4Z9aESJMcdxDP2s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statistik/judul-skripsi-terdaftar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\StatistikController@judul_skripsi_terdaftar',
        'controller' => 'App\\Http\\Controllers\\StatistikController@judul_skripsi_terdaftar',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::a4Z9aESJMcdxDP2s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NTlny6MDIFZFkRtP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statistik/riwayat-kp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\StatistikController@riwayat_lokasi_kp',
        'controller' => 'App\\Http\\Controllers\\StatistikController@riwayat_lokasi_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::NTlny6MDIFZFkRtP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jJTjQniETDcX6lEq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail/kuota-bimbingan/kp/{nip}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_kuota_bimbingan_kp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_kuota_bimbingan_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jJTjQniETDcX6lEq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gQqG7b2A2GhtmvvU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail/lulus-bimbingan/kp/{nip}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\StatistikController@detail_lulus_bimbingan_kp',
        'controller' => 'App\\Http\\Controllers\\StatistikController@detail_lulus_bimbingan_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gQqG7b2A2GhtmvvU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::96klo3NyiQNSmPaz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail/lulus-bimbingan/skripsi/{nip}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\StatistikController@detail_lulus_bimbingan_skripsi',
        'controller' => 'App\\Http\\Controllers\\StatistikController@detail_lulus_bimbingan_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::96klo3NyiQNSmPaz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ja45FtmMpZPYqF35' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'detail/kuota-bimbingan/skripsi/{nip}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_kuota_bimbingan_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_kuota_bimbingan_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ja45FtmMpZPYqF35',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eeM52cz66ipN4oqF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kuota-bimbingan/kp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@kuotabimbingan_kp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@kuotabimbingan_kp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::eeM52cz66ipN4oqF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yxo77vabRWTfWlsE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kuota-bimbingan/skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@kuotabimbingan_skripsi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@kuotabimbingan_skripsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yxo77vabRWTfWlsE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IiTSkmNlFOQ9YXYB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-semkp/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detailusulansemkp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detailusulansemkp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IiTSkmNlFOQ9YXYB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6SDb5BJuwjgiHq5B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-sempro/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailsempro',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailsempro',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6SDb5BJuwjgiHq5B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AAgOtqnHXgTIOOc3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-sidang/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailsidang',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailsidang',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::AAgOtqnHXgTIOOc3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LnpZV7vOfvUKV3vW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'surat-permohonankp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web,dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@kpti_1',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@kpti_1',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LnpZV7vOfvUKV3vW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::msoNss7F6W0YEZCp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-kp/edit/koordinator/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@edit_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@edit_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::msoNss7F6W0YEZCp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ljr5aIVf9dwWfHDS' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'form-kp/edit/koordinator/{penjadwalan_kp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@update_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@update_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ljr5aIVf9dwWfHDS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_kp' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a7JOc5yybo5cULUb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-sempro/edit/koordinator/{penjadwalan_sempro}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@edit_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@edit_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::a7JOc5yybo5cULUb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lvPy0BoblaHj4GBu' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'form-sempro/edit/koordinator/{penjadwalan_sempro}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@update_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@update_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lvPy0BoblaHj4GBu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_sempro' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lEdXg50YukY6DBUv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-skripsi/edit/koordinator/{penjadwalan_skripsi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@edit_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@edit_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lEdXg50YukY6DBUv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_skripsi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a5M6KSKiuBXHdLym' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'form-skripsi/edit/koordinator/{penjadwalan_skripsi}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@update_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@update_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::a5M6KSKiuBXHdLym',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_skripsi' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T2guoPfWWp7WYjtc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'form-kp/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@edit',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::T2guoPfWWp7WYjtc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QoskYpIX042AAcR9' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'form-kp/edit/{penjadwalan_kp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@update',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QoskYpIX042AAcR9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
        'penjadwalan_kp' => 'id',
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LXvpsKEZ2sTRd6v5' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'lewat-batas-balasan/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:dosen',
          4 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@lewat_batas_balasan',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@lewat_batas_balasan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LXvpsKEZ2sTRd6v5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0Sam6CTxpi6GvcbN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'developer/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@create',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0Sam6CTxpi6GvcbN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rlU95rBKGJ7WJAcR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'developer/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@store',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rlU95rBKGJ7WJAcR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DSQWi8tKlERM8TnY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'developer/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@edit',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DSQWi8tKlERM8TnY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wYWQI5DL84AZvojI' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'developer/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\DeveloperController@update',
        'controller' => 'App\\Http\\Controllers\\DeveloperController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wYWQI5DL84AZvojI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zAW2TZ4NLYjpEgRD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan-koordinator',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@persetujuan_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@persetujuan_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zAW2TZ4NLYjpEgRD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HE1jtUEx9eMtmzH9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan-koordinator/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@detail_persetujuan_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@detail_persetujuan_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HE1jtUEx9eMtmzH9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::B3KZoMJ6eM09aqFI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayat-koordinator',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@riwayat_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@riwayat_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::B3KZoMJ6eM09aqFI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WsfFBWb6Vqo88l9K' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuankp-koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@approve_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@approve_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WsfFBWb6Vqo88l9K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::agP4O9fILYBfJX8P' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuankp-koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@tolak_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@tolak_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::agP4O9fILYBfJX8P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R2v8JOy0SSEqVoUK' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuanskripsi-koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@approve_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@approve_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::R2v8JOy0SSEqVoUK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::399Hb1hGq4ruUkAu' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuanskripsi-koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@tolak_koordinator',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@tolak_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::399Hb1hGq4ruUkAu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5jjrNreuafV0Qw26' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulankp/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulankp_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulankp_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5jjrNreuafV0Qw26',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XQpQkgNtdbZ0XpEt' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulankp/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulan_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulan_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XQpQkgNtdbZ0XpEt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ckOIDdcbc2bFckaE' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'balasankp/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approvebalasankp_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approvebalasankp_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ckOIDdcbc2bFckaE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XRJVBVelG0Z0uj5u' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'balasankp/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakbalasankp_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakbalasankp_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XRJVBVelG0Z0uj5u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::slyQmZDMviIJyzB6' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kpti10/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approvekpti10_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approvekpti10_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::slyQmZDMviIJyzB6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y3o8nPcyjKttPEo1' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kpti10/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakkpti10_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakkpti10_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Y3o8nPcyjKttPEo1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::194cKmfigiwUkcwi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usuljudul/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveusuljudul',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveusuljudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::194cKmfigiwUkcwi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PMhE4vSzfzdgYaa9' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usuljudul/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakusuljudul_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakusuljudul_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PMhE4vSzfzdgYaa9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zilHPR2WRgVEBEjE' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsempro/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsempro_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsempro_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zilHPR2WRgVEBEjE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3day3PNbJkw72eEw' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsempro/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsempro_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsempro_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3day3PNbJkw72eEw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WBX6vMrEzZl0tCra' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan2/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan2_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan2_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WBX6vMrEzZl0tCra',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H8zYSwnaw3rEZ7f7' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan2/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan2_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan2_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::H8zYSwnaw3rEZ7f7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BM7ndPt5rD8DRk95' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan-revisi/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan_revisi_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan_revisi_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BM7ndPt5rD8DRk95',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OaRr3uXS770nYSau' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan-revisi/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan_revisi_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan_revisi_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OaRr3uXS770nYSau',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z8wIl422kuPd7H3L' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'buku-skripsi/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvebuku_skripsi_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvebuku_skripsi_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::z8wIl422kuPd7H3L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fhj11JNDWxq43dWh' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'buku-skripsi/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakbuku_skripsi_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakbuku_skripsi_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fhj11JNDWxq43dWh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Uy92MJ6KDFWTaqd9' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsidang/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsidang_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsidang_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Uy92MJ6KDFWTaqd9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lrNUTP5tx3mGvpBW' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsidang/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsidang_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsidang_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lrNUTP5tx3mGvpBW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BAmtFeXE4LgZVuYh' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'nilaikpkeluar/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approvenilai_keluar_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approvenilai_keluar_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BAmtFeXE4LgZVuYh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::x661nmS9RyjA73y7' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'nilaiskripsikeluar/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvelulus_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvelulus_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::x661nmS9RyjA73y7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bVDvWO46sLsgxrBZ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulan-semkp/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulan_semkp_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulan_semkp_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::bVDvWO46sLsgxrBZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7fIdGoZMAZFmtwAO' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulan-semkp/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolak_semkp_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolak_semkp_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7fIdGoZMAZFmtwAO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::E2Imzwp1D2TxdS33' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftar-sempro/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolak_sempro_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolak_sempro_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::E2Imzwp1D2TxdS33',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QVuwikqi6PMBxXPl' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftar-sempro/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approve_sempro_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approve_sempro_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QVuwikqi6PMBxXPl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SpOmPEB05jSPRz0K' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftar-sidang/koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolak_sidang_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolak_sidang_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SpOmPEB05jSPRz0K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A9cKDztMThpuPXCi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftar-sidang/koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approve_sidang_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approve_sidang_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::A9cKDztMThpuPXCi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NC6D3ATCDyl0x55U' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'pendaftarankp-koordinator/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approve_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approve_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::NC6D3ATCDyl0x55U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CFtbwC1QdOLyAmdX' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perdaftarankp-koordinator/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:9,10,11',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolak_koordinator',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolak_koordinator',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CFtbwC1QdOLyAmdX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'peminjamanplp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/peminjaman-plp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanPLPController@index',
        'controller' => 'App\\Http\\Controllers\\PeminjamanPLPController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'peminjamanplp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4osUpkvmnsbyPoXW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/setuju-plp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanPLPController@setujuplp',
        'controller' => 'App\\Http\\Controllers\\PeminjamanPLPController@setujuplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4osUpkvmnsbyPoXW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eXavYfTpRd78YizB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/tolak-plp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanPLPController@ditolakplp',
        'controller' => 'App\\Http\\Controllers\\PeminjamanPLPController@ditolakplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::eXavYfTpRd78YizB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IfKP9fsWnXMwmEWG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/kembali-plp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\PeminjamanPLPController@kembaliplp',
        'controller' => 'App\\Http\\Controllers\\PeminjamanPLPController@kembaliplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IfKP9fsWnXMwmEWG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'riwayatplp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/riwayat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\RiwayatController@riwayatplp',
        'controller' => 'App\\Http\\Controllers\\RiwayatController@riwayatplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'riwayatplp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'stokplp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/stok-plp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@indexplp',
        'controller' => 'App\\Http\\Controllers\\BarangController@indexplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'stokplp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'stokbaruplp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'inventaris/stokbaru-plp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@createplp',
        'controller' => 'App\\Http\\Controllers\\BarangController@createplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'stokbaruplp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tambahbarangplp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/tambahbarang-plp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@addbarangplp',
        'controller' => 'App\\Http\\Controllers\\BarangController@addbarangplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'tambahbarangplp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'deletebarangplp' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'inventaris/deletebarang-plp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@destroyplp',
        'controller' => 'App\\Http\\Controllers\\BarangController@destroyplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'deletebarangplp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'editbarangplp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inventaris/editbarang-plp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@editplp',
        'controller' => 'App\\Http\\Controllers\\BarangController@editplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'editbarangplp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'updatebarangplp' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'inventaris/updatebarang-plp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:web',
          3 => 'cekrole:12',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@updateplp',
        'controller' => 'App\\Http\\Controllers\\BarangController@updateplp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'updatebarangplp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5a23pASd9QuIbXcB' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulankp/kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulankp_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulankp_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5a23pASd9QuIbXcB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hnfLRxRkzCrjwSBU' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulankp/kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulan_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolakusulan_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hnfLRxRkzCrjwSBU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JND1NYmXBxxT5JID' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan-kaprodi/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@detail_persetujuan_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@detail_persetujuan_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JND1NYmXBxxT5JID',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ML0LUMp0faiYdNW7' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulan-semkp/kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulan_semkp_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@approveusulan_semkp_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ML0LUMp0faiYdNW7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f1Yn2TcDoSoFDp4G' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usulan-semkp/kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@tolak_semkp_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@tolak_semkp_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::f1Yn2TcDoSoFDp4G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jcT6tKOACrdunsgw' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan1/kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan1_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan1_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jcT6tKOACrdunsgw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AOILtKCqiXKJ4vGU' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan1/kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan1_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan1_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::AOILtKCqiXKJ4vGU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mZtdulmsM46IQjfn' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan2/kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan2_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan2_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mZtdulmsM46IQjfn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pzXoo0e5hR8MyKa9' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan2/kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan2_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan2_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pzXoo0e5hR8MyKa9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FIaHvLH3dZP4d5DK' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan-revisi/kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan_revisi_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveperpanjangan_revisi_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FIaHvLH3dZP4d5DK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J8cZQySQd152sMsz' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjangan-revisi/kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan_revisi_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakperpanjangan_revisi_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::J8cZQySQd152sMsz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M2Kz8xH7AQC3Gwcm' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usuljudul/kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveusuljudul_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approveusuljudul_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::M2Kz8xH7AQC3Gwcm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QCDFWfjsYjvP0nTL' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'usuljudul/kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakusuljudul_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakusuljudul_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QCDFWfjsYjvP0nTL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cKeHkndzFhfxmaSd' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsempro/kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsempro_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approvedaftarsempro_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cKeHkndzFhfxmaSd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2pHy6FN5VzW2YJ94' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftarsempro/kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsempro_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolakdaftarsempro_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2pHy6FN5VzW2YJ94',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oNoBH0ofSI2gIoxY' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftar-sidang/kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolak_sidang_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@tolak_sidang_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::oNoBH0ofSI2gIoxY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sAmG9F92EEscgD6c' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'daftar-sidang/kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approve_sidang_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@approve_sidang_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::sAmG9F92EEscgD6c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ceDfDANGnCdo8oHd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'persetujuan-kaprodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@persetujuan_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@persetujuan_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ceDfDANGnCdo8oHd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aA5080NnhBrnYubg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'riwayat-kaprodi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanController@riwayat_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanController@riwayat_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::aA5080NnhBrnYubg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l1wWeIz5fgbKp0gq' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuankp-kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@approve_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@approve_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::l1wWeIz5fgbKp0gq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pNd1fYXb46DUFWiq' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuankp-kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanKPController@tolak_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanKPController@tolak_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pNd1fYXb46DUFWiq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mfTBpVRnq54yqifz' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuansempro-kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@approve_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@approve_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mfTBpVRnq54yqifz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mUMSa1IT5dryHDXk' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuansempro-kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSemproController@tolak_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSemproController@tolak_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mUMSa1IT5dryHDXk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sguXW3GZgw2fvxEJ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuanskripsi-kaprodi/approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@approve_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@approve_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::sguXW3GZgw2fvxEJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::c0K51UMQ5GCvPbUX' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'persetujuanskripsi-kaprodi/tolak/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'auth:dosen',
          3 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@tolak_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PenjadwalanSkripsiController@tolak_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::c0K51UMQ5GCvPbUX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::k8nJrJIbDVbg8idQ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'perpanjang-revisi/spesial/kaprodi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'prevent-back-history',
          2 => 'prevent-back-history',
          3 => 'auth:dosen',
          4 => 'cekrole:6,7,8',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@spesial_kaprodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@spesial_kaprodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::k8nJrJIbDVbg8idQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s8X5wUA8bYyNkWHw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@index',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::s8X5wUA8bYyNkWHw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7xQjCvNh767N6glI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usulan/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detailusulankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detailusulankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7xQjCvNh767N6glI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JPYyHK8llH6ujZWi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usuljudul/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailusuljudul',
        'controller' => 'App\\Http\\Controllers\\PendaftaranSkripsiController@detailusuljudul',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JPYyHK8llH6ujZWi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GW3Mw8zeaxq9ZWB1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'permohonan-kp/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpermohonankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpermohonankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GW3Mw8zeaxq9ZWB1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PKO5D4XN6E5YQbsU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'balasan-kp/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detailbalasankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detailbalasankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PKO5D4XN6E5YQbsU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cZF4eUk1Sm9iS7T7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'balasan-kp/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@indexbalasan',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@indexbalasan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cZF4eUk1Sm9iS7T7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l0H4UXIMRfgD94Sm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'balasan-kp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@create',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::l0H4UXIMRfgD94Sm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rzcTwIP50GVdScnz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'balasan-kp/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,mahasiswa',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@store',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rzcTwIP50GVdScnz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UtZS23wHgOWMsobh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usulan/detail/pembimbingprodi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detailusulan_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detailusulan_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UtZS23wHgOWMsobh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YJUGLDKknXuaKMO1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'suratperusahaan/detail/pembimbingprodi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detailbalasan_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detailbalasan_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YJUGLDKknXuaKMO1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EnW6nJKwFxpWBalr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kpti10/detail/pembimbingprodi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detailkpti10_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detailkpti10_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EnW6nJKwFxpWBalr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0GNSkXOtO8HaR72W' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kpti10/detail/riwayat/pembimbingprodi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detail_riwayat_kpti10_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detail_riwayat_kpti10_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0GNSkXOtO8HaR72W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KZVonX9xTbSQhEF7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'prodi/riwayat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@riwayat_prodi',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@riwayat_prodi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::KZVonX9xTbSQhEF7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tkkIJemMnRjoCead' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kerja-praktek/nilai-keluar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@nilai_keluar',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@nilai_keluar',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::tkkIJemMnRjoCead',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0eJbP3mRLC9gxTad' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'skripsi/nilai-keluar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@lulus',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@lulus',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0eJbP3mRLC9gxTad',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::awEiMjXK9JFq6cmO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'usuljudul/detail/pembimbing/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detailusuljudul_pembimbing',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detailusuljudul_pembimbing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::awEiMjXK9JFq6cmO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZZrKMRoFHW9AAFjT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-sempro/detail/pembimbing/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detailsempro_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detailsempro_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ZZrKMRoFHW9AAFjT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6Y2HtojvX1IBWvRD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'daftar-sidang/detail/pembimbing/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranController@detailsidang_pemb',
        'controller' => 'App\\Http\\Controllers\\PendaftaranController@detailsidang_pemb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6Y2HtojvX1IBWvRD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QPt2VzFcncQMFlD3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/usulankp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpersetujuan_usulankp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpersetujuan_usulankp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QPt2VzFcncQMFlD3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hWIvouJmtyim78OA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kp-skripsi/persetujuan/semkp/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:dosen,web',
        ),
        'uses' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpersetujuan_semkp',
        'controller' => 'App\\Http\\Controllers\\PendaftaranKPController@detailpersetujuan_semkp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hWIvouJmtyim78OA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
