<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PublikasiJurnal extends Model
{
    protected $table = 'publikasi_jurnal';
    protected $guarded = [];
    use HasFactory;
}
