<?php

namespace App\Models\Mbkm;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MataKuliah extends Model
{
    use HasFactory;
    protected $table = "mata_kuliah";
    protected $guarded = [];
}
