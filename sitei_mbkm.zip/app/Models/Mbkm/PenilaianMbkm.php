<?php

namespace App\Models\Mbkm;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PenilaianMbkm extends Model
{
    use HasFactory;
    protected $table = "mbkm_penilaian_mbkm";
    protected $guarded = [];
}
