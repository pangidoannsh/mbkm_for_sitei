<?php

namespace App\Http\Controllers;

use App\Models\BatalSeminar;
use Illuminate\Http\Request;

class BatalSeminarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\BatalSeminar  $batalSeminar
     * @return \Illuminate\Http\Response
     */
    public function show(BatalSeminar $batalSeminar)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\BatalSeminar  $batalSeminar
     * @return \Illuminate\Http\Response
     */
    public function edit(BatalSeminar $batalSeminar)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\BatalSeminar  $batalSeminar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BatalSeminar $batalSeminar)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\BatalSeminar  $batalSeminar
     * @return \Illuminate\Http\Response
     */
    public function destroy(BatalSeminar $batalSeminar)
    {
        //
    }
}
