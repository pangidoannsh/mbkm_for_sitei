<?php

namespace App\Http\Controllers\Mbkm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UsulanController extends Controller
{
    //
}
